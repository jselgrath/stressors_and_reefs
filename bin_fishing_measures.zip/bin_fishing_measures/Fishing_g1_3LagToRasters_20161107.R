# Jennifer Selgrath 
# Calculate cumulative impact fishing .tif files

# To create lag (varitions of 1960-2000) values for fishing pressure maps - here in coral areas only
# gears used here: g1 gears destructive to reefs and some g5 and gear cat from ch3
###############################################

library(raster)
remove(list=ls())

######################################
# Stack and organize the rasters of fishing effort
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_norm/"
setwd(loc3) 

# load and stack files 

# g1
files.b<-list.files(pattern=c('g1_b'));files.b;s.b<-stack(files.b)
files.k<-list.files(pattern=c('g1_k'));s.k<-stack(files.k)
files.p<-list.files(pattern=c('g1_p'));s.p<-stack(files.p)

#Ch3 - g5 and categories
files.p2<-list.files(pattern=c('.g5_p.*.tif$')); files.p2;s.p2<-stack(files.p2) # includes aquarium fishing
files.b2<-list.files(pattern=c('.*g5_b.*.tif$')); files.b2;s.b2<-stack(files.b2) # same as blast above
files.nS<-list.files(pattern=c('.*nS.*.tif$')); files.nS;s.nS<-stack(files.nS) #nonSelective
files.i<-list.files(pattern=c('.*i.*.tif$')); files.i;s.i<-stack(files.i) #illegal
files.a<-list.files(pattern=c('.*a.*.tif$')); files.a; s.a<-stack(files.a) # active


######################
# Calc Cum Fishing with a Lag (ie not including current year)
##########

# Calc cumulative years
# std by max for all years

lagf<-function(x=s.b,group1="blast"){
	
	lYr10A=x[[5]]
	lYr20A=x[[5]]+x[[4]]
	lYr30A=x[[5]]+x[[4]]+x[[3]]
	lYr40A=x[[5]]+x[[4]]+x[[3]]+x[[2]]
	lYr50A=x[[5]]+x[[4]]+x[[3]]+x[[2]]+x[[1]] 
	
	# stack
	x2<-stack(lYr10A,lYr20A,lYr30A,lYr40A,lYr50A)
	grp=group1 #this names the gear subset calc
	
	names(x2)<-c(paste(grp,"10",sep=""),paste(grp,"20",sep=""),paste(grp,"30",sep=""),paste(grp,"40",sep=""),paste(grp,"50",sep=""))
	return(x2)
}

# calc lag values
lag.b<-lagf(x=s.b,group1="blast"); lag.b
lag.p<-lagf(x=s.p,group1="poison"); lag.p
lag.k<-lagf(x=s.k,group1="kaykay"); lag.k

lag.g5p<-lagf(x=s.p2,group1="g5poison"); lag.g5p
lag.nS<-lagf(x=s.nS,group1="nSel"); lag.nS
lag.i<-lagf(x=s.i,group1="il"); lag.i
lag.a<-lagf(x=s.a,group1="act"); lag.a

########################
#export lag rasters
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_lag") #results file

expt2<-function(x){
	writeRaster(x,filename="lag.tif",dataType="GTiff",bylayer=T, overwrite=T, suffix=names(x))
}

expt2(lag.b)
expt2(lag.p)
expt2(lag.k)

expt2(lag.g5p)
expt2(lag.nS)
expt2(lag.i)
expt2(lag.a)


# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures") 