# Jennifer Selgrath 
# Calculate cumulative impact fishing .tif files

# To create maps of changes in values for fishing pressure - here in coral areas only
# all fishing gears included here
###############################################

library(raster)
remove(list=ls())


######################################
# Stack and organize the rasters of fishing effort
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_norm/"
setwd(loc3) 

# load and stack files 

# g1
files.b<-list.files(pattern=c('g1_b'));files.b;s.b<-stack(files.b)
files.k<-list.files(pattern=c('g1_k'));s.k<-stack(files.k)
files.p<-list.files(pattern=c('g1_p'));s.p<-stack(files.p)

#Ch3 - g5 and categories
files.p2<-list.files(pattern=c('.g5_p.*.tif$')); files.p2;s.p2<-stack(files.p2) # includes aquarium fishing
files.b2<-list.files(pattern=c('.*g5_b.*.tif$')); files.b2;s.b2<-stack(files.b2) # same as blast above
files.nS<-list.files(pattern=c('.*nS.*.tif$')); files.nS;s.nS<-stack(files.nS) #nonSelective
files.i<-list.files(pattern=c('.*i.*.tif$')); files.i;s.i<-stack(files.i) #illegal
files.a<-list.files(pattern=c('.*a.*.tif$')); files.a; s.a<-stack(files.a) # active


##########
# Calc difference in fishing pressure among years
# std by max for all years

diff<-function(x=s.b,group1="blast"){

f1<-x[[6]]-x[[5]] #2010-2000
f2<-x[[6]]-x[[4]] #2010-1990
f3<-x[[6]]-x[[3]] #2010-1980
f4<-x[[5]]-x[[4]] #2000-1990
f5<-x[[4]]-x[[3]] #1990-1980

# stack
x2<-stack(f1,f2,f3,f4,f5)
grp=group1 #this names the gear subset calc
names(x2)<-c(paste(grp,"10_00",sep=""),paste(grp,"10_90",sep=""),paste(grp,"10_80",sep=""),paste(grp,"00_90",sep=""),paste(grp,"90_80",sep=""))
return(x2)
}

# calc dif values
dif.b<-diff(x=s.b,group1="blast"); dif.b
dif.p<-diff(x=s.p,group1="poison"); dif.p
dif.k<-diff(x=s.k,group1="kaykay"); dif.k

dif.g5p<-diff(x=s.p2,group1="g5poison"); dif.g5p
dif.nS<-diff(x=s.nS,group1="nSel"); dif.nS
dif.i<-diff(x=s.i,group1="il"); dif.i
dif.a<-diff(x=s.a,group1="act"); dif.a


########################
#export difference rasters
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_dif") #results file

expt<-function(x){
	writeRaster(x,filename="dif.tif",dataType="GTiff",bylayer=T, overwrite=T, suffix=names(x))
}

expt(dif.b)
expt(dif.p)
expt(dif.k)

expt(dif.g5p)
expt(dif.nS)
expt(dif.i)
expt(dif.a)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures") 
