# Jennifer Selgrath 
# Calculate cumulative impact fishing .tif files

# To create normalized values for fishing pressure maps - here in coral areas only
# destructive fishing gears included here
#################################

library(raster)
remove(list=ls())

############################
# TASK 1.1 Load polygon of coral/rubble area

#read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/coralrubble")

CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

#return wd
setwd(loc)


######################################
# Stack and organize the rasters of fishing effort
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates"
setwd(loc3) 

files<-list.files(pattern=c(".tif$","est_dayYr_dest1"))
files
files2<-files[37:42]
head(files2)

s <- stack(files2)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('dest1960','dest1970', 'dest1980','dest1990','dest2000',"dest2010")
names(s) = new_names

# Mask rasters so only evaluating fishnig effort in coral areas
s2<-mask(s, CA) #,inverse=TRUE
str(s2)
str(s)

names(s2)

plot(s[[1]])
plot(s2[[1]])

# Calculate max for each year for Coral and Rubble Area only
# or better for values within the range of the samples??
mx.yr<-vector('numeric')
for (i in 1:nl){
	val<-s2[[i]]@data@max
	max<-round(val,0)
	mx.yr<-rbind(mx.yr,max)
}

mx.yr
mx.all<-max(mx.yr)


##########################
# Calculate normalized variables (value at a site/max value), See Maynard et al 2015
# NOTE: I Confirmed and NAs are in places with no fishing info...

######## these ones are normalized by the year they were in ###########
#set empty raster stack
s3<-stack()

# create loop to fill it
for (i in 1:nl){
	temp<-s2[[i]]/mx.yr[i]
	s3<-stack(s3,temp)
}
max(s3[[1]])
names(s3)

######## these ones are normalized by all years ###########
#set empty raster stack
s4<-stack()

# create loop to fill it
for (i in 1:nl){
	nms<-names(s2[[i]])
	temp<-round(s2[[i]]/mx.all,4)
	names(temp)<-nms
	s4<-stack(s4,temp)
}
max(s4[[1]])
max(s4[[6]])

names(s4)

########################
#export Normalized rasters
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/Dest_norm_CoralArea") #results file

for (i in 1:nl){
	nms<-names(s4[[i]])
	writeRaster(s4[[i]],paste(nms,"Norm.tif",sep=""), format="GTiff", overwrite=TRUE)
}

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures") 
