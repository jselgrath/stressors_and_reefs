# Jennifer Selgrath 
# Calculate cumulative impact fishing .tif files

# To create normalized values for fishing pressure maps - here in coral areas only
# all fishing gears included here

library(raster)
remove(list=ls())

############################
# TASK 1.1 Load polygon of coral/rubble area

# #read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/coralrubble")
CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE)

#########################
# Task: Load rasters from g1 evaluation
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates/Ch3_DayYr_3calc_ReefDest_Combo")

# load files 
files.b<-list.files(pattern=c('b'));files.b
files.k<-list.files(pattern=c('k'))
files.p<-list.files(pattern=c('p'))

# stack files
s.b<-stack(files.b)
s.k<-stack(files.k)
s.p<-stack(files.p)

# load rasters from Ch3
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates")
files.p2<-list.files(pattern=c('.*poison.*.tif$')); files.p2;s.p2<-stack(files.p2)
files.b2<-list.files(pattern=c('.*blast.*.tif$')); files.b2;s.b2<-stack(files.b2)
files.nS<-list.files(pattern=c('.*nonSel1.*.tif$')); files.nS;s.nS<-stack(files.nS)
files.i<-list.files(pattern=c('.*illegal1.*.tif$')); files.i;s.i<-stack(files.i)
files.a<-list.files(pattern=c('.*active1.*.tif$')); files.a; s.a<-stack(files.a)


# change names of Ch3 datasets to something better
new_names.b2 = c('g5_b1960','g5_b1970','g5_b1980','g5_b1990','g5_b2000',"g5_b2010");names(s.b2)=new_names.b2 #blast
new_names.p2=c('g5_p1960','g5_p1970','g5_p1980','g5_p1990','g5_p2000',"g5_p2010");names(s.p2)=new_names.p2 #poison
new_names.nS=c('g5_nS1960','g5_nS1970','g5_nS1980','g5_nS1990','g5_nS2000',"g5_nS2010");names(s.nS)=new_names.nS #nonSelective
new_names.i=c('g5_i1960','g5_i1970','g5_i1980','g5_i1990','g5_i2000',"g5_i2010");names(s.i)=new_names.i #illegal
new_names.a=c('g5_a1960','g5_a1970','g5_a1980','g5_a1990','g5_a2000',"g5_a2010");names(s.a)=new_names.a #active

################
# Normalizing fishing effort
# Calculate normalized variables (value at a site/max value), See Maynard et al 2015
# NOTE: I Confirmed and NAs are in places with no fishing info...

nrm<-function(x=s.b, msk = CA){
	nl <- nlayers(x)
	x2<-mask(x,msk) # Mask rasters so only evaluating fishnig effort in coral areas
	mx.yr<-vector('numeric')
	
	for (i in 1:nl){
		val<-x2[[i]]@data@max
		max<-round(val,0)
		mx.yr<-rbind(mx.yr,max)
	}
	mx.all<-max(mx.yr)
	
	######## these ones are normalized by all years ###########
	#set empty raster stack
	s4<-stack()
	
	# create loop to fill it
	for (i in 1:nl){
		nms<-names(x2[[i]])
		temp<-round(x2[[i]]/mx.all,4)
		names(temp)<-nms
		s4<-stack(s4,temp)
	}
	return(s4)
}

# normalize g1n data
sN.b<-nrm(x=s.b,msk=CA);sN.b
sN.p<-nrm(x=s.p,msk=CA);sN.p
sN.k<-nrm(x=s.k,msk=CA);sN.k

#normalize Ch3 data
sN.b2<-nrm(x=s.b2,msk=CA);sN.b2
sN.p2<-nrm(x=s.p2,msk=CA);sN.p2
sN.i<-nrm(x=s.i,msk=CA);sN.i
sN.a<-nrm(x=s.a,msk=CA);sN.a
sN.nS<-nrm(x=s.nS,msk=CA);sN.nS

# compare blast from g1n and Ch3
sN.b;sN.b2 # they are the same - good!

########################
#export Normalized rasters
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_norm") #results file

expt<-function(x){
	writeRaster(x,filename="nrm.tif",dataType="GTiff",bylayer=T, overwrite=T, suffix=names(x))
}

# export raster stacks
expt(sN.b)
expt(sN.p)
expt(sN.k)

expt(sN.b2)
expt(sN.p2)
expt(sN.i)
expt(sN.a)
expt(sN.nS)


# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures") 


######## below is code to normalize by the year they were in ###########
# #set empty raster stack
# s3<-stack()
# 
# # create loop to fill it
# for (i in 1:nl){
# 	temp<-s2[[i]]/mx.yr[i]
# 	s3<-stack(s3,temp)
# }
# max(s3[[1]])
# names(s3)

##################
