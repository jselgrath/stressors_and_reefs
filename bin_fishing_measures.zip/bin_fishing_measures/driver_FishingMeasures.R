# Jennifer Selgrath
# Project Seahorse, UBC

# Goal: Driver for code to build rasters of measures of fishing effort used in modeling. Measures: normalized fishing pressure, cumulative fishing pressure, lag fishing pressure, changes in fishing pressure
# Fishing types: All gears, Destructive gears as a class; Individual destructive gears affecting reefs
###############################################
remove(list=ls())

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures")

########################
# For all fishing effort
########################

# 
source("Fishing_1NormalizedToRasters_20160825.R") # normalize effort
source("Fishing_2CumToRasters_20160825.R") # calculate cumulative effort over decades
source("Fishing_3DiffToRasters_20160916.R") # calculate changes in effort

########################
# For all destructive fishing effort
########################
source("FishingDest_1NormalizedToRasters_20160825.R")
source("FishingDest_2CumToRasters_20160825.R")
source("FishingDest_3DifToRasters_20160916.R")

########################
# For specific destructive fishing effort
########################
source("Fishing_g1_0CombineGears_20161107.R")
# output in folder ".../data/fishing/EffortEstimates/Ch3_DayYr_3calc_ReefDest_Combo

source("Fishing_g1_1NormalizedToRasters_20161107.R") # for some g5 & categories too
# output in folder: ".../data/fishing/g1_norm"

source("Fishing_g1_2CumToRasters_20161107.R")
# output in folder: "...data/fishing/g1_cum"

source("Fishing_g1_3LagToRasters_20161107.R")
# output in folder: "...data/fishing/g1_lag"

source("Fishing_g1_4DifToRasters_20161107.R")
# output in folder: "...data/fishing/g1_dif"
