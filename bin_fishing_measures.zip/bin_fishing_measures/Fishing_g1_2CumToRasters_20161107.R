# Jennifer Selgrath 
# Calculate cumulative impact fishing .tif files

# To create cumulative (varitions of 1960-2010) values for fishing pressure maps - here in coral areas only
# gears used here: g1 gears destructive to reefs and some g5 and gear cat from ch3
###############################################

library(raster)
remove(list=ls())

######################################
# Stack and organize the rasters of fishing effort
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_norm/"
setwd(loc3) 

# load and stack files 

# g1
files.b<-list.files(pattern=c('g1_b'));files.b;s.b<-stack(files.b)
files.k<-list.files(pattern=c('g1_k'));s.k<-stack(files.k)
files.p<-list.files(pattern=c('g1_p'));s.p<-stack(files.p)

#Ch3 - g5 and categories
files.p2<-list.files(pattern=c('.g5_p.*.tif$')); files.p2;s.p2<-stack(files.p2) # includes aquarium fishing
files.b2<-list.files(pattern=c('.*g5_b.*.tif$')); files.b2;s.b2<-stack(files.b2) # same as blast above
files.nS<-list.files(pattern=c('.*nS.*.tif$')); files.nS;s.nS<-stack(files.nS) #nonSelective
files.i<-list.files(pattern=c('.*i.*.tif$')); files.i;s.i<-stack(files.i) #illegal
files.a<-list.files(pattern=c('.*a.*.tif$')); files.a; s.a<-stack(files.a) # active

##########
# Calc cumulative years
# std by max for all years

cumf<-function(x=s.b,group1="blast"){

	fYr00A=x[[6]]
	fYr10A=x[[6]]+x[[5]]
	fYr20A=x[[6]]+x[[5]]+x[[4]]
	fYr30A=x[[6]]+x[[5]]+x[[4]]+x[[3]]
	fYr40A=x[[6]]+x[[5]]+x[[4]]+x[[3]]+x[[2]] 
	fYr50A=x[[6]]+x[[5]]+x[[4]]+x[[3]]+x[[2]]+x[[1]]

	# stack
	x2<-stack(fYr00A,fYr10A,fYr20A,fYr30A,fYr40A,fYr50A)
	grp=group1 #this names the gear subset calc
	names(x2)<-c(paste(grp,"00",sep=""),paste(grp,"10",sep=""),paste(grp,"20",sep=""),paste(grp,"30",sep=""),paste(grp,"40",sep=""),paste(grp,"50",sep=""))
	return(x2)
}

# calc cumulative values
cum.b<-cumf(x=s.b,group1="blast"); cum.b
cum.p<-cumf(x=s.p,group1="poison"); cum.p
cum.k<-cumf(x=s.k,group1="kaykay"); cum.k

cum.g5p<-cumf(x=s.p2,group1="g5poison"); cum.g5p
cum.nS<-cumf(x=s.nS,group1="nSel"); cum.nS
cum.i<-cumf(x=s.i,group1="il"); cum.i
cum.a<-cumf(x=s.a,group1="act"); cum.a


########################
#export cumulative rasters
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_cum") #results file

expt<-function(x){
	writeRaster(x,filename="cum.tif",dataType="GTiff",bylayer=T, overwrite=T, suffix=names(x))
}

expt(cum.b)
expt(cum.p)
expt(cum.k)

expt(cum.g5p)
expt(cum.nS)
expt(cum.i)
expt(cum.a)


##########################
# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures") 
