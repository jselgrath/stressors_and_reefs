# Jennifer Selgrath
# Project Seahorse, UBC

# Calculate cumulative impact fishing .tif files

# To create cumulative (varitions of 1960-2010) values for fishing pressure maps - here in coral areas only
# all fishing gears included here
###############################################

library(raster)
remove(list=ls())

############################
# TASK 1.1 Load polygon of coral/rubble area


#read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/coralrubble")
CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

######################################
# Stack and organize the rasters of fishing effort
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/All_norm_CoralArea/"
setwd(loc3) 

files<-list.files(pattern=c('.tif$','all'))
s <- stack(files)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('all1960','all1970', 'all1980','all1990','all2000',"all2010")
names(s) = new_names

plot(s[[1]]) #should be on 0-1 scale
max(s[[1]])

##########
# Calc cumulative years
# std by max for all years
fYr00A=s[[6]]
fYr10A=s[[6]]+s[[5]]
fYr20A=s[[6]]+s[[5]]+s[[4]]
fYr30A=s[[6]]+s[[5]]+s[[4]]+s[[3]]
fYr40A=s[[6]]+s[[5]]+s[[4]]+s[[3]]+s[[2]] 
fYr50A=s[[6]]+s[[5]]+s[[4]]+s[[3]]+s[[2]]+s[[1]]

# stack
s3<-stack(fYr00A,fYr10A,fYr20A,fYr30A,fYr40A,fYr50A)
names(s3)<-c("CumFishing_all_00","CumFishing_all_10","CumFishing_all_20","CumFishing_all_30","CumFishing_all_40","CumFishing_all_50")
names(s3)

########################
#export cumulative rasters
loc4<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/All_cum_CoralArea/"
setwd(loc4)

for (i in 1:nl){
	nms<-names(s3[[i]])
	writeRaster(s3[[i]],paste(nms,".tif",sep=""), format="GTiff", overwrite=TRUE)
}

######################
# Calc Cum Fishing with a Lag (ie not including current year)
##########

# Calc cumulative years
# std by max for all years
lYr10A=s[[5]]
lYr20A=s[[5]]+s[[4]]
lYr30A=s[[5]]+s[[4]]+s[[3]]
lYr40A=s[[5]]+s[[4]]+s[[3]]+s[[2]]
lYr50A=s[[5]]+s[[4]]+s[[3]]+s[[2]]+s[[1]] 


# stack
s4<-stack(lYr10A,lYr20A,lYr30A,lYr40A,lYr50A)
names(s4)<-c("CumFishing_all_Lag10","CumFishing_all_Lag20","CumFishing_all_Lag30","CumFishing_all_Lag40","CumFishing_all_Lag50")
names(s4)

########################
#export cumulative lag rasters
loc4<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/All_cum_CoralArea/"
setwd(loc4)

for (i in 1:5){
	nms<-names(s4[[i]])
	writeRaster(s4[[i]],paste(nms,".tif",sep=""), format="GTiff", overwrite=TRUE)
}

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures") 
