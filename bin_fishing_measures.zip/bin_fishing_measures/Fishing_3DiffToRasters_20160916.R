# Jennifer Selgrath 
# Calculate cumulative impact fishing .tif files

# To create maps of changes in values for fishing pressure - here in coral areas only
# all fishing gears included here
###############################################

library(raster)
remove(list=ls())

############################
# TASK 1.1 Load polygon of coral/rubble area


#read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/coralrubble")
CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

######################################
# Stack and organize the rasters of fishing effort
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/All_norm_CoralArea/"
setwd(loc3) 

files<-list.files(pattern=c('.tif$','all'))
s <- stack(files)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('all1960','all1970', 'all1980','all1990','all2000',"all2010")
names(s) = new_names

plot(s[[1]]) #should be on 0-1 scale
max(s[[1]])

##########
# Calc difference in fishing pressure among years
# std by max for all years


dDif10A=s[[5]]
dDif20A=s[[5]]+s[[4]]
dDif30A=s[[5]]+s[[4]]+s[[3]]
dDif40A=s[[5]]+s[[4]]+s[[3]]+s[[2]] 
dDif50A=s[[5]]+s[[4]]+s[[3]]+s[[2]]+s[[1]]

#2010 - 2000
f1<-s[[6]]-s[[5]]
plot(f1)

#2010 - (1990)
f2<-s[[6]]-s[[4]]#dDif20A
plot(f2)

#2010 - (1980)
f3<-s[[6]]-s[[3]]
plot(f3)

#2000-1990
f4<-s[[5]]-s[[4]]
plot(f4)

#1990-1980
f5<-s[[4]]-s[[3]] #all fishing went up
plot(f5)

# stack
s3<-stack(f1,f2,f3,f4,f5)
names(s3)<-c("DifFishing_all_10_00","DifFishing_all_10_90","DifFishing_all_10_80","DifFishing_all_00_90","DifFishing_all_90_80")
names(s3)

########################
#export difference rasters
loc4<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/All_dif_CoralArea/"
setwd(loc4)

for (i in 1:5){
	nms<-names(s3[[i]])
	writeRaster(s3[[i]],paste(nms,".tif",sep=""), format="GTiff", overwrite=TRUE)
}



# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/FishingMeasures") 
