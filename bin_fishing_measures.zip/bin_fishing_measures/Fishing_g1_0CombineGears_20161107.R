# Jennifer Selgrath 
# Calculate cumulative impact fishing .tif files

# To combine similar gears for evaluation of gears specifically destructive to reef
# combining day and night kaykay and day and night posion plus poison with twisting (not including aquarium fishing)

library(raster)
remove(list=ls())


######################################
# Stack and combine the rasters of related fishing effort (e.g. day and night versions of gear)

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates/Ch3_DayYr_3calc_ReefDest") 

loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates/Ch3_DayYr_3calc_ReefDest"


# load files and organize by gears
files<-list.files(pattern=c('.tif$'))
files

#blast
f1.b<-files[1:6];f1.b  #blast
s.b <- stack(f1.b); names(s.b);  dataType(s.b)

f1.bg<-files[7:12]; f1.bg # blast gatherer
s.bg <- stack(f1.bg); names(s.bg); nl <- nlayers(s.bg); dataType(s.bg)

#kaykay
f1.k<-files[13:18]; f1.k   # day
s.k <- stack(f1.k); names(s.k); nl <- nlayers(s.k); dataType(s.k)

f1.kn<-files[19:22]; f1.kn # night
s.kn <- stack(f1.kn); names(s.kn); nl <- nlayers(s.kn); dataType(s.kn)

#poison
f1.pd<-files[23:24] #day
s.pd <- stack(f1.pd); names(s.pd); nl <- nlayers(s.pd); dataType(s.pd)

f1.pn<-files[25:26] #night
s.pn <- stack(f1.pn); names(s.pn); nl <- nlayers(s.pn); dataType(s.pn)

f1.pt<-files[27:31] #twisting
s.pt <- stack(f1.pt); names(s.pt); nl <- nlayers(s.pt); dataType(s.pt)


#########
# combine blast and blast gatherer (this was in orig ch3 analysis)
s.b2<-stack(s.b+s.bg)
nl.b <- nlayers(s.b2);nl.b
s.b2

# comparing blast, blast gatherer, and summed files. This works!
# plot(s.b2[[1]]) 
# plot(s.bg[[1]])
# plot(s.b[[1]])


# kay kay day and night: different length rasters
# temp files
t.k2.60<-s.k [[1]];t.k2.70<-s.k [[2]]; t.k2.80<-s.k [[3]]+s.kn[[1]]; t.k2.90<-s.k [[4]]+s.kn[[2]]; t.k2.00<-s.k [[5]]+s.kn[[3]]; t.k2.10<-s.k [[6]]+s.kn[[4]]

s.k2<-stack(t.k2.60,t.k2.70,t.k2.80,t.k2.90,t.k2.00,t.k2.10)
s.k2; nl.k <- nlayers(s.k2);nl.k

# poison
t.p1<-s.pd+s.pn # add day and night (1960 & 1970 only)
t.p2<-t.p1[[2]]+s.pt[[1]] # poison and twisting for 1970
s.p2<-stack(t.p1[[1]],t.p2,s.pt[[2]],s.pt[[3]],s.pt[[4]],s.pt[[5]])
s.p2



# change names to something better
new_names.b = c('b1960','b1970', 'b1980','b1990','b2000',"b2010"); 
names(s.b2) = new_names.b # blast

new_names.k = c('k1960','k1970', 'k1980','k1990','k2000',"k2010"); 
names(s.k2) = new_names.k #kaykay

new_names.p = c('p1960','p1970', 'p1980','p1990','p2000',"p2010"); 
names(s.p2) = new_names.p #poison

########################
# export rasters
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates/Ch3_DayYr_3calc_ReefDest_Combo")

writeRaster(s.b2,filename="g1.tif",dataType="GTiff",bylayer=T, overwrite=T, suffix=names(s.b2))
writeRaster(s.k2,filename="g1.tif",dataType="GTiff",bylayer=T, overwrite=T, suffix=names(s.k2))
writeRaster(s.p2,filename="g1.tif",dataType="GTiff",bylayer=T, overwrite=T, suffix=names(s.p2))


############
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")


