# Jennifer Selgrath
# August 3, 2016
# Coral resilience to fishing impacts

# correlation of variables

# GOAL: visualizing data
############################################################################
library(corrplot)
library(ggplot2)
library(dplyr)
##############################################################################
remove(list=ls())

loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch5/Resilience/results/RS_only")
setwd(loc)

list.files(loc)

# load data #
d1<-read.csv("IndpVar_Ptsc_RS.csv",header = T); names(d1)
# this is the vesion with LEK habitat map info removed
str(d1)

################
names(d1) #should have new variables from sourced code

########################
# Correlations between variables
cor(d1$z.sgProx,d1$z.mg_minDist)
cor(d1$z.distBgy.km,d1$z.SRdistTown.km)
cor(d1$z.SRdistTown.km,d1$z.mg_minDist)


# filtr out just fishing variables
names(d1)
d.f<-dplyr::select(d1,fYr00A:dfYrLag50A,PopRsk.Nrm)
head(d.f)
str(d.f)
dfcor<-round(cor(d.f, use="complete"),2)
dfcor<-data.frame(dfcor)
corrplot(dfcor)

names(dfcor)

dfcor2<-select(dfcor,fYr00A:dfYrLag50A)
dfcor2<-as.matrix(dfcor2)
corrplot(dfcor2, method="number", type = "lower")

# Dest fishing 00 is not correlated  with fishing >= 20 years
# dest fishing lag 10 or lag 20 is not correlated with fishign at 00.
# >.7 is threshold here


# save
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/doc")
write.table(dfcor,file="correlationsFishing.csv", sep=",", col.names = T,row.names = T)

# 0.7 threshold. SIGen not sig correl. could use FreqAll OR FreqDest+FreqNonDest
# fishing and dest fishing stop being highly correlated for 20+ years ago (e.g. fYr20A)

#distance to MG and SG var

plot(r.j~d1$sg_minDist)
plot(r.j~d1$mg_minDist)

plot(r.j~d1$sgProx)
plot(r.j~d1$mgProx)

names(d1)
# d1$sgNEAR_DISTu2<-as.numeric(d1$sgNEAR_DISTu2)
# d1$mgNEAR_DISTu2<-as.numeric(d1$mgNEAR_DISTu2)

d.h<-dplyr::select(d1,sg_minDist:sgProx,mg_minDist:mgProx,PopRsk.Nrm,ENN)
dhcor<-round(cor(d.h, use="complete"),2)
dhcor
corrplot(dhcor)
# mean and min distance correlated, others independent

#dist variables
#town (enforcenment & market) and market (Pasil, sales) correlated
d.d<-dplyr::select(d1,distBgy.km,distTown.km,distMarket.km,distRiver.km,PopRsk.Nrm,sg_minDist,mg_minDist)
ddcor<-round(cor(d.d, use="complete"),2)
ddcor
corrplot(ddcor)

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")
