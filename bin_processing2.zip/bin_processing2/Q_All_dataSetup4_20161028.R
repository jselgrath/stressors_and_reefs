# Jennifer Selgrath
# August 4, 2016
# Coral resilience to fishing impacts

# GOAL: Code to analyze the relationship between coral (Coral (1) vs. rubble (0)) and various threats and biophysical parameters.

# TAKE HOME 1: 
# NO difference between using all fishing time series of 30,40,or 50 years # see versions of old code for this conclusion

############################################################
# library("MuMIn")
# library(lme4)
# library(car) # function Anova - correct checking on models
# library(lsmeans)
# library(ggplot2)
##########################

remove(list=ls())

# loc=("C:/worksp/Ch4/R.proj/Resilience/results") 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)


# load data 
d1<-read.csv("IndpVar_Ptsc_RS.csv",header = T) 
head(d1)
names(d1)
# str(d1)
d1<-na.omit(d1)

##########################
# remove Olango - not focus of data collection so trust it less
d2<-filter(d1,d1$EcoZone!="Olango") 
str(d2)

options(na.action = "na.fail")

# remove enormous outlier for earlier run of model PtID = 4272
d2<-filter(d2,d2$CID!="4272") 


##############################
# NOTES:
# leave out mgProx & sgProx? -  model throws errors with mgProx
# # z.LCoRuEdg2Area #not better with edge/area composite
# using LPopRsk.nrm instead of reefs at risk data because RaR data was non-sensical
# dist to river and mangroves are - correlated


# combine terrestrial island and coastal ecological zones
d2$EcoZone2<-as.character(d2$EcoZone)
d2$EcoZone2[d2$EcoZone2=="Terrestrial Island"]<-"Coastal"

# remove coastal - test
d3<-filter(d2,d2$EcoZone2!="Coastal") 
d3$EcoZone2<-as.factor(d3$EcoZone2)

###########
names(d2)

# select relevant variables
d4<-dplyr::select(d2,x:yearEst,z.Ldepth:EcoZone2)
names(d4)
# write this versio of data to table
# d2 = all ecological zones, d3 = no coastal
setwd(loc)
write.table(d4,file="IndpVar_Ptsd_RS.csv",col.names = T,row.names = F, sep=",")
write.table(d3,file="IndpVar_Ptsd_RS_NoCoastalTerr_RS.csv",col.names = T,row.names = F, sep=",")

#############################################
#reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")
