# Jennifer Selgrath
# June 2,2016
# Coral resilience to fishing impacts

#####################################
# GOAL: set up variables for models
# ***this code should be run inside of the analysis models when data = d1***
#####################################

         
######################################################
# round effort var for days per year
# d1$allEffort2010<-round(d1$allEffort2010,0)
# d1$destEffort2010<-round(d1$destEffort2010,0)
# d1$nonDestEffort2010<-round(d1$nonDestEffort2010,0)

################
# transforming
###############
d1$Depth_m<- -1*d1$Depth_m # make depth positive
d1$Ldepth<-log((d1$Depth_m)+1)

d1$LCoRuArea<-log(d1$CoRuArea+1)
d1$LCoRuLngth<-log(d1$CoRuLngth+1)
d1$LdistBgy.km<-log(d1$distBgy.km+1)
d1$LdistRiver.km<-log(d1$distRiver.km+1)
d1$LdistTown.km<-log(d1$distTown.km+1)
d1$LdistMarket.km<--1*abs(log(d1$distMarket.km+1)) #make dist to market negative
d1$LPopRsk.Nrm<-log(d1$PopRsk.Nrm+1)


d1$Lsg_minDist100<-log((d1$sg_minDist/100)+1)
d1$Lmg_minDist100<-log((d1$mg_minDist/100)+1)
d1$Lco_minDist100<-log((d1$co_minDist/100)+1)

# log landscape variables
d1$LAREA<-log(d1$AREA+1)
d1$LPARA<-log(d1$PARA+1)
d1$LENN<-log(d1$ENN+1)
d1$LSHAPE<-log(d1$SHAPE+1)

# edge/area
qplot(log(d1$CoRuLngth/d1$CoRuArea)+1)
d1$CoRuEdg2Area<-d1$CoRuLngth/d1$CoRuArea
d1$LCoRuEdg2Area<-log(d1$CoRuLngth/d1$CoRuArea)+1
d1$c.LCoRuEdg2Area<-d1$LCoRuEdg2Area-mean(d1$LCoRuEdg2Area)

#############################
# Calculated fishing variables
##############################
d1$LfYr00A<-log(d1$fYr00A+1)
d1$LfYr10A<-log(d1$fYr10A+1)
d1$LfYr20A<-log(d1$fYr20A+1)
d1$LfYr30A<-log(d1$fYr30A+1)
d1$LfYr40A<-log(d1$fYr40A+1)
d1$LfYr50A<-log(d1$fYr50A+1)

# dest fishing
d1$LdfYr00A<-log(d1$dfYr00A+1)
d1$LdfYr10A<-log(d1$dfYr10A+1)
d1$LdfYr20A<-log(d1$dfYr20A+1)
d1$LdfYr30A<-log(d1$dfYr30A+1)
d1$LdfYr40A<-log(d1$dfYr40A+1)
d1$LdfYr50A<-log(d1$dfYr50A+1)

# Lag fishing variables
qplot(log(d1$fYrLag30A+1))
qplot(log(d1$fYrLag30A+1))

d1$LfYrLag10A<-log(d1$fYrLag10A+1)
d1$LfYrLag20A<-log(d1$fYrLag20A+1)
d1$LfYrLag30A<-log(d1$fYrLag30A+1)
d1$LfYrLag40A<-log(d1$fYrLag40A+1)
d1$LfYrLag50A<-log(d1$fYrLag50A+1)

d1$LdfYrLag10A<-log(d1$dfYrLag10A+1)
d1$LdfYrLag20A<-log(d1$dfYrLag20A+1)
d1$LdfYrLag30A<-log(d1$dfYrLag30A+1)
d1$LdfYrLag40A<-log(d1$dfYrLag40A+1)
d1$LdfYrLag50A<-log(d1$dfYrLag50A+1)

# changes
# due to changes with negative values use log-modulus transformation
# http://www.statsblogs.com/2014/07/14/a-log-transformation-of-positive-and-negative-values/

d1$temp1<- 1
d1$temp1[d1$allDif_10_90<0]<- -1
d1$LallDif_00_90<- log(d1$allDif_00_90+1)*d1$temp1 

d1$temp2<- 1
d1$temp2[d1$allDif_10_00<0]<- -1
d1$LallDif_10_00<- log(d1$allDif_10_00+1)*d1$temp2 

d1$temp3<- 1
d1$temp3[d1$allDif_10_80<0]<- -1
d1$LallDif_10_80<- log(abs(d1$allDif_10_80 +1))*d1$temp3

d1$temp4<- 1
d1$temp4[d1$allDif_10_90<0]<- -1
d1$LallDif_10_90<- log(abs(d1$allDif_10_90+1))*d1$temp4

d1$temp5<- 1
d1$temp5[d1$destDif_00_90<0]<- -1
d1$LdestDif_00_90<-log(d1$destDif_00_90+1)*d1$temp5

d1$temp6<- 1
d1$temp6[d1$destDif_10_00<0]<- -1
d1$LdestDif_10_00<-log(d1$destDif_10_00 +1)*d1$temp6 

d1$temp7<- 1
d1$temp7[d1$destDif_10_80<0]<- -1
d1$LdestDif_10_80<-log(d1$destDif_10_80+1)*d1$temp7

d1$temp8<- 1
d1$temp8[d1$destDif_10_90<0]<- -1
d1$LdestDif_10_90<-log(d1$destDif_10_90+1)*d1$temp8
# d1$LdestDif_90_80<-log(d1$destDif_90_80+1)

#############################
# centering variables based on mean
# from gelman and hill p 55
##############################

# fishing
d1$c.LfYr00A<-d1$LfYr00A - mean(d1$LfYr00A)
d1$c.LfYr10A<-d1$LfYr10A - mean(d1$LfYr10A)
d1$c.LfYr20A<-d1$LfYr20A - mean(d1$LfYr20A)
d1$c.LfYr30A<-d1$LfYr30A - mean(d1$LfYr30A)
d1$c.LfYr40A<-d1$LfYr40A - mean(d1$LfYr40A)
d1$c.LfYr50A<-d1$LfYr50A - mean(d1$LfYr50A)

d1$c.fYr30A<-d1$fYr30A - mean(d1$fYr30A)
d1$c.fYr00A<-d1$fYr00A - mean(d1$fYr00A)

# destructive fishing
d1$c.LdfYr00A<-d1$LdfYr00A - mean(d1$LdfYr00A)
d1$c.LdfYr10A<-d1$LdfYr10A - mean(d1$LdfYr10A)
d1$c.LdfYr20A<-d1$LdfYr20A - mean(d1$LdfYr20A)
d1$c.LdfYr30A<-d1$LdfYr30A - mean(d1$LdfYr30A)
d1$c.LdfYr40A<-d1$LdfYr40A - mean(d1$LdfYr40A)
d1$c.LdfYr50A<-d1$LdfYr50A - mean(d1$LdfYr50A)

# fishing lag
d1$c.LfYrLag10A<-d1$LfYrLag10A - mean(d1$LfYrLag10A)
d1$c.LfYrLag20A<-d1$LfYrLag20A - mean(d1$LfYrLag20A)
d1$c.LfYrLag30A<-d1$LfYrLag30A - mean(d1$LfYrLag30A)
d1$c.LfYrLag40A<-d1$LfYrLag40A - mean(d1$LfYrLag40A)
d1$c.LfYrLag50A<-d1$LfYrLag50A - mean(d1$LfYrLag50A)

d1$c.fYrLag30A<-d1$fYrLag30A - mean(d1$fYrLag30A)

# dest fishing lag
d1$c.LdfYrLag10A<-d1$LdfYrLag10A - mean(d1$LdfYrLag10A)
d1$c.LdfYrLag20A<-d1$LdfYrLag20A - mean(d1$LdfYrLag20A)
d1$c.LdfYrLag30A<-d1$LdfYrLag30A - mean(d1$LdfYrLag30A)
d1$c.LdfYrLag40A<-d1$LdfYrLag40A - mean(d1$LdfYrLag40A)
d1$c.LdfYrLag50A<-d1$LdfYrLag50A - mean(d1$LdfYrLag50A)

# change in fishing & dest fishing
d1$c.LallDif_00_90<- d1$LallDif_00_90 - mean(d1$LallDif_00_90)  
d1$c.LallDif_10_00<- d1$LallDif_10_00 - mean(d1$LallDif_10_00)
d1$c.LallDif_10_80<- d1$LallDif_10_80 - mean(d1$LallDif_10_80)
d1$c.LallDif_10_90<- d1$LallDif_10_90 - mean(d1$LallDif_10_90)   
# d1$c.LallDif_90_80<- d1$LallDif_90_80 - mean(d1$LallDif_90_80) 

d1$c.LdestDif_00_90<-d1$LdestDif_00_90-mean(d1$LdestDif_00_90)
d1$c.LdestDif_10_00<-d1$LdestDif_10_00-mean(d1$LdestDif_10_00)   
d1$c.LdestDif_10_80<-d1$LdestDif_10_80-mean(d1$LdestDif_10_80)
d1$c.LdestDif_10_90<-d1$LdestDif_10_90-mean(d1$LdestDif_10_90)
# d1$c.LdestDif_90_80<-d1$LdestDif_90_80-mean(d1$LdestDif_90_80) 

# other var
d1$c.Ldepth<-d1$Ldepth - mean(d1$Ldepth)
d1$c.Id_MPAb<-d1$Id_MPAb-mean(d1$Id_MPAb)
# d1$c.LsgProx<-d1$sgProx-mean(d1$sgProx)
# d1$c.LmgProx<-d1$mgProx - mean(d1$mgProx)
d1$c.Lsg_minDist100<-d1$Lsg_minDist100-mean(d1$Lsg_minDist100)
d1$c.Lmg_minDist100<-d1$Lmg_minDist100-mean(d1$Lmg_minDist100)
d1$c.Lco_minDist100<-d1$Lco_minDist100-mean(d1$Lco_minDist100)

# d1$mg_minDist100<-d1$mg_minDist/100
# d1$c.Lmg_minDist100<-(d1$mg_minDist100-mean(d1$mg_minDist100))
# d1$sg_minDist100<-d1$sg_minDist/100
# d1$c.Lsg_minDist100<-(d1$sg_minDist100-mean(d1$sg_minDist100))
# d1$co_minDist100<-d1$co_minDist/100
# d1$c.Lco_minDist100<-(d1$co_minDist100-mean(d1$co_minDist100))

d1$c.LCoRuLngth<-d1$LCoRuLngth-mean(d1$LCoRuLngth)
d1$c.LCoRuArea<-d1$LCoRuArea-mean(d1$LCoRuArea)

d1$c.therm_98_07<-d1$therm_98_07-mean(d1$therm_98_07)

d1$c.distBgy.km<-d1$distBgy.km-mean(d1$distBgy.km)

d1$c.LdistRiver.km<-d1$LdistRiver.km-mean(d1$LdistRiver.km)
d1$c.LdistBgy.km<-d1$LdistBgy.km-mean(d1$LdistBgy.km)
d1$c.LdistTown.km<-d1$LdistTown.km - mean(d1$LdistTown.km)
d1$c.LdistMarket.km<-d1$LdistMarket.km - mean(d1$LdistMarket.km)

d1$c.divSpec2010 <- d1$divSpec2010 - mean (d1$divSpec2010)
d1$c.SIGen2010 <- d1$SIGen2010 - mean (d1$SIGen2010)




# center logged variables
d1$c.LAREA <- d1$LAREA - mean (d1$LAREA)
d1$c.LPARA <- d1$LPARA - mean (d1$LPARA)
d1$c.LENN <- d1$LENN - mean (d1$LENN)
d1$c.ENN <- d1$ENN - mean (d1$ENN)
d1$c.LSHAPE <- d1$LSHAPE - mean (d1$LSHAPE)

# pop density based risk
d1$c.LPopRsk.Nrm<-d1$LPopRsk.Nrm - mean(d1$LPopRsk.Nrm)
d1$c.PopRsk.Nrm<-d1$PopRsk.Nrm - mean(d1$PopRsk.Nrm)


#############################
# standardizing by subtracting mean and / 2 StdDev
# from gelman and hill p 56
##############################

#fishing
d1$z.LfYr00A<-d1$c.LfYr00A/(2*sd(d1$LfYr00A))
d1$z.LfYr10A<-d1$c.LfYr10A/(2*sd(d1$LfYr10A))
d1$z.LfYr20A<-d1$c.LfYr20A/(2*sd(d1$LfYr20A))
d1$z.LfYr30A<-d1$c.LfYr30A/(2*sd(d1$LfYr30A))
d1$z.LfYr40A<-d1$c.LfYr40A/(2*sd(d1$LfYr40A))
d1$z.LfYr50A<-d1$c.LfYr50A/(2*sd(d1$LfYr50A))

d1$z.fYr30A<-d1$c.fYr30A/(2*sd(d1$fYr30A))
d1$z.fYr00A<-d1$c.fYr00A/(2*sd(d1$fYr00A))

# dest fishing
d1$z.LdfYr00A<-d1$c.LdfYr00A/(2*sd(d1$LdfYr00A))
d1$z.LdfYr10A<-d1$c.LdfYr10A/(2*sd(d1$LdfYr10A))
d1$z.LdfYr20A<-d1$c.LdfYr20A/(2*sd(d1$LdfYr20A))
d1$z.LdfYr30A<-d1$c.LdfYr30A/(2*sd(d1$LdfYr30A))
d1$z.LdfYr40A<-d1$c.LdfYr40A/(2*sd(d1$LdfYr40A))
d1$z.LdfYr50A<-d1$c.LdfYr50A/(2*sd(d1$LdfYr50A))

#fishing lag
d1$z.LfYrLag10A<-d1$c.LfYrLag10A/(2*sd(d1$LfYrLag10A))
d1$z.LfYrLag20A<-d1$c.LfYrLag20A/(2*sd(d1$LfYrLag20A))
d1$z.LfYrLag30A<-d1$c.LfYrLag30A/(2*sd(d1$LfYrLag30A))
d1$z.LfYrLag40A<-d1$c.LfYrLag40A/(2*sd(d1$LfYrLag40A))
d1$z.LfYrLag50A<-d1$c.LfYrLag50A/(2*sd(d1$LfYrLag50A))

d1$z.fYrLag30A<-d1$c.fYrLag30A/(2*sd(d1$fYrLag30A))

# dest fishing lag
d1$z.LdfYrLag10A<-d1$c.LdfYrLag10A/(2*sd(d1$LdfYrLag10A))
d1$z.LdfYrLag20A<-d1$c.LdfYrLag20A/(2*sd(d1$LdfYrLag20A))
d1$z.LdfYrLag30A<-d1$c.LdfYrLag30A/(2*sd(d1$LdfYrLag30A))
d1$z.LdfYrLag40A<-d1$c.LdfYrLag40A/(2*sd(d1$LdfYrLag40A))
d1$z.LdfYrLag50A<-d1$c.LdfYrLag50A/(2*sd(d1$LdfYrLag50A))

# change in fishing & dest fishing
d1$z.LallDif_00_90<- d1$c.LallDif_00_90 - (2*sd(d1$LallDif_00_90))  
d1$z.LallDif_10_00<- d1$c.LallDif_10_00 - (2*sd(d1$LallDif_10_00))
d1$z.LallDif_10_80<- d1$c.LallDif_10_80 - (2*sd(d1$LallDif_10_80))
d1$z.LallDif_10_90<- d1$c.LallDif_10_90 - (2*sd(d1$LallDif_10_90))   
# d1$z.LallDif_90_80<- d1$c.LallDif_90_80 - (2*sd(d1$LallDif_90_80)) 

d1$z.LdestDif_00_90<-d1$c.LdestDif_00_90-(2*sd(d1$c.LdestDif_00_90))
d1$z.LdestDif_10_00<-d1$c.LdestDif_10_00-(2*sd(d1$c.LdestDif_10_00))   
d1$z.LdestDif_10_80<-d1$c.LdestDif_10_80-(2*sd(d1$c.LdestDif_10_80))
d1$z.LdestDif_10_90<-d1$c.LdestDif_10_90-(2*sd(d1$c.LdestDif_10_90))
# d1$z.LdestDif_90_80<-d1$c.LdestDif_90_80-(2*sd(d1$c.LdestDif_90_80)) 

#other var
d1$z.Ldepth<-d1$c.Ldepth/(2*sd(d1$Ldepth))
d1$z.Id_MPAb<-d1$c.Id_MPAb/(2*sd(d1$Id_MPAb))
# d1$z.sgProx<-d1$c.LsgProx/(2*sd(d1$sgProx))
# d1$z.mgProx<-d1$c.LmgProx/(2*sd(d1$mgProx))
# d1$z.Lsg_minDist<-d1$c.Lsg_minDist/(2*sd(d1$Lsg_minDist))
# d1$z.Lmg_minDist<-d1$c.Lmg_minDist/(2*sd(d1$Lmg_minDist))
# d1$z.Lco_minDist<-d1$c.Lco_minDist/(2*sd(d1$Lco_minDist))

d1$z.Lmg_minDist100<-d1$c.Lmg_minDist100/(2*sd(d1$Lmg_minDist100))
d1$z.Lsg_minDist100<-d1$c.Lsg_minDist100/(2*sd(d1$Lsg_minDist100))
d1$z.Lco_minDist100<-d1$c.Lco_minDist100/(2*sd(d1$Lco_minDist100))

d1$z.LCoRuLngth<-d1$c.LCoRuLngth/(2*sd(d1$LCoRuLngth))
d1$z.LCoRuArea<-d1$c.LCoRuArea/(2*sd(d1$LCoRuArea))

d1$z.therm_98_07<-d1$c.therm_98_07/(2*sd(d1$therm_98_07))

d1$z.distBgy.km<-d1$c.distBgy.km/(2*sd(d1$distBgy.km))

d1$z.LdistRiver.km<-d1$c.LdistRiver.km/(2*sd(d1$LdistRiver.km))
d1$z.LdistBgy.km<-d1$c.LdistBgy.km/(2*sd(d1$LdistBgy.km))
d1$z.LdistTown.km<-d1$c.LdistTown.km/(2*sd(d1$LdistTown.km))
d1$z.LdistMarket.km<-d1$c.LdistMarket.km/(2*sd(d1$LdistMarket.km))

d1$z.divSpec2010<-d1$c.divSpec2010 /(2*sd( d1$divSpec2010))
d1$z.SIGen2010<-d1$c.SIGen2010 /(2*sd(d1$SIGen2010))

# center logged variables
d1$z.LAREA<-d1$c.LAREA /(2*sd(d1$LAREA))
d1$z.LPARA<-d1$c.LPARA /(2*sd(d1$LPARA))
d1$z.LENN<-d1$c.LENN /(2*sd(d1$LENN))
d1$z.ENN<-d1$c.ENN /(2*sd(d1$ENN))
d1$z.LSHAPE<-d1$c.LSHAPE /(2*sd(d1$LSHAPE))

d1$z.LCoRuEdg2Area<-d1$c.LCoRuEdg2Area/(2*sd(d1$LCoRuEdg2Area))

# pop density based risk
d1$z.LPopRsk.Nrm<-d1$c.LPopRsk.Nrm /(2*sd(d1$LPopRsk.Nrm))
d1$z.PopRsk.Nrm<-d1$c.PopRsk.Nrm /(2*sd(d1$PopRsk.Nrm))

###############################
# Make codes into factors
d1$Id_geom<-as.factor(d1$Id_geom)
d1$EcoZone<-as.factor(d1$EcoZone)
# d1$Id_MunWtr<-as.factor(d1$Id_MunWtr)
# d1$Id_dMg<-as.factor(d1$Id_dMg)
# d1$Id_dSg<-as.factor(d1$Id_dSg)
d1$Id_MPAc<-as.factor(d1$Id_MPAc)
d1$Id_MPAb<-as.factor(d1$Id_MPAb)






########################

