# Jennifer Selgrath
# November 08, 2016
# Ch4

# GOAL: Load g1n some g5n and Ch3 categories effort estimates from all years
# NOTE: some of these I calculated so I have them if I need them. Goal is to test blast, kaykay and poison/aquarium fishing.
#######################################################
library(raster)
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

#read in shapefile of random point with resilience data
# ogrInfo(".","hab_Resil_Pts_RS")
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) 
# str(pts)
# length(unique(pts@data$CID))


######################################
# Stack and organize the rasters of fishing effort

# loc1<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_norm"
# loc2<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_cum"
loc2<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_lag"
# loc2<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/g1_dif"

# lag files - list, then stack
setwd(loc2) 
files.b<-list.files(pattern=c('.*blast*.'));s.b<-stack(files.b);s.b
files.p<-list.files(pattern=c('.*_poison*.'));s.p<-stack(files.p);s.p
files.p2<-list.files(pattern=c('.*5poison*.'));s.p2<-stack(files.p2);s.p2
files.k<-list.files(pattern=c('.*kaykay*.'));s.k<-stack(files.k);s.k
files.a<-list.files(pattern=c('.*act*.'));s.a<-stack(files.a);s.a
files.i<-list.files(pattern=c('.*il*.'));s.i<-stack(files.i);s.i
files.nS<-list.files(pattern=c('.*nSel*.'));s.nS<-stack(files.nS);s.nS
plot(s.b[[1]]) 

###########################################
#Extract Raster Variables to Point Data

lagf<-function(x=s.b,group1="blast",pnts=pts){
	grp=group1 #this names the gear subset calc
	nms<-names(x)
	x2<-data.frame(coordinates(pts),
               pts$CID,
							 raster::extract(x,pnts))
	names(x2)<-c("x","y","CID",nms)
	return(x2)
}

p.b<- lagf(x=s.b, group1="blast");    head(p.b)
p.p<- lagf(x=s.p, group1="poison");   head(p.p)
p.p2<-lagf(x=s.p2,group1="g5poison"); head(p.p2)
p.k<- lagf(x=s.k, group1="kaykay");   head(p.k)

p.i<- lagf(x=s.k, group1="illegal");   head(p.k)
p.a<- lagf(x=s.k, group1="active");   head(p.k)
p.nS<- lagf(x=s.k, group1="nonSel");   head(p.k)


########################
#export points with lag values
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only") #results file

expt<-function(x,group1="blast"){
	write.table(x,file=paste("pts_lagFishing_g1n_",group1,".csv",sep=""), sep=",", col.names=T, row.names=F)
}

expt(p.b, group1="blast")
expt(p.p, group1="poison")
expt(p.k, group1="kaykay")

expt(p.p2, group1="g5poison")
expt(p.nS, group1="nonSel")
expt(p.i, group1="illegal")
expt(p.a, group1= "active")


# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 




