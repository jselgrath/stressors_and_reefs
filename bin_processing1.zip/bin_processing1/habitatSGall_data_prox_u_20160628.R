# Jennifer Selgrath
# June 21,2016
# Coral resilience to fishing impacts

#####################################
# GOAL: find mean values for distance from coral patches to mangrove or seagrass patches

#Data from ArcGIS Generate near table
###################################
library (plyr)
library(dplyr)
library(ggplot2)

###########################
#LoadData
########################
remove(list=ls())

loc<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/prox"
setwd(loc)
list.files(loc)
# distance between coral patches and seagrass patches or mangrove patches
# remote sensing data only
# sg est as only med/high or anything with sg

# co: dist to sg, mg
d1<- read.csv(file = "RS_CoRu_SG_dist_ANYm.csv", header = T, stringsAsFactors = F, strip.white = TRUE, na.strings = c("NA","","na"))

head(d1)
length(unique(d1$IN_FID)) #coral/Rubble simplified FID

#label
d1$NEAR_FC<-"seagrass"

head(d1)

levels(as.factor(d1$NEAR_FC))

# load SGall polygons to get data
# ogrInfo(".","SGall_smplfd_20160628")
sg<-readOGR(".","SGall_smplfd_20160628",stringsAsFactors=TRUE) 
sg@data$NEAR_FID = rownames(sg@data)
head(sg@data)


# merge area data from sg polygons with subsetted distance data (sg all only)
sg2<-data.frame(sg@data)
head(sg2)

sg3 = merge.data.frame(d1,sg2, all=FALSE, by = "NEAR_FID")
tail(sg3)

range(sg3$NEAR_DIST) #0-2614m
qplot(sg3$NEAR_DIST)

names(sg3)

sg3$NEAR_DIST[sg3$NEAR_DIST==0]<-.0001 #make adjacent patches have a very low distance to address dividing by 0 issues

#calculate intermediate value for PROX
sg3$proxInt<-sg3$Shape_Area/(sg3$NEAR_DIST^2)
max(sg3$proxInt)
qplot(log(sg3$proxInt+1))

names(sg3)

length(levels(as.factor(sg3$IN_FID)))

# summarize 
d3<-ddply(sg3,c("IN_FID","NEAR_FC"),summarize, #near FC is file name
          sgNEARn=length(NEAR_DIST),
          sgNEAR_DISTmin=round(min(NEAR_DIST),2),
          sgNEAR_DISTu=round(mean(NEAR_DIST),2),
          sgNEAR_DISTsd=round(sd(NEAR_DIST),2),
          sgNEAR_DISTse=round(sgNEAR_DISTsd/sqrt(sgNEARn),2),
          sgProx=sum(proxInt))

head(d3)

range(d3$sgProx)
qplot(d3$sgProx)
qplot(d3$sgNEAR_DISTmin)
qplot(d3$sgNEAR_DISTu)
levels(as.factor(d3$NEAR_FC))

length(levels(as.factor(d3$IN_FID)))

#######################
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
write.table(d3,file="SGallProx1_RS.csv", sep=",", col.names=T, row.names=F)

# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")

