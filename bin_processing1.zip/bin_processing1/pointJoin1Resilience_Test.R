# Jennifer Selgrath
# May 24, 2016
# July 31, 2016 UPDATED TO USE POINTS IN 19x22 AREA ONLY. details about point # etc NOT updated below.

# extract resilience variable to points

#########################
# library(dplyr)
# library(raster)
# library(dismo) # if generating random points here
# library (rgdal) #reading shapefiles
# library(spatialEco) # point in polygons
# library(sp)

#########################
remove(list=ls())
loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/randomPts/")
setwd(loc1)

########### 
# import point data from GIS - random points, 100m apart min, in Coral Area only, 50m from orig points, > 100m from MPA boundary, no Olango

# need to manually assign PtID

#https://www.nceas.ucsb.edu/scicomp/usecases/ReadWriteESRIShapeFiles

#read in shapefile of random points
pt<-readOGR(".","TestingPts_CoRu_19x22_NoOlango_50away") 
print(proj4string(pt)) # check projection
str(pt@data)
length(pt@data$PtID)
length(unique(pt@data$PtID))

loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/resilience/")
setwd(loc2)

#read in shapefile of habitat and resilience data
# this has most of the detailed info
# ogrInfo(".","RS_FocalArea_Updated_20160627b") 
hab<-readOGR(".","RS_FocalArea_Updated_20160627b") 
head(hab@data)

# read in simplified polygons for length/area
habS<-readOGR(".","CoRu_Smplfd_20160628") 
head(habS@data)

# extract hab polygon data to points
pt2 <- point.in.poly(pt, hab)
names(pt2@data)

# update CID to PtID, which fixed CID problems
pt2@data$CID<-pt2@data$PtID;names(pt2@data) 

# extract simplified habtiat polygon data to points
pt12 <- point.in.poly(pt, habS)
names(pt12@data)

# update CID to PtID, which fixed CID problems
pt12@data$CID<-pt12@data$PtID;head(pt12@data)

# convert to data frame, keeping your data
pt3<- as.data.frame(pt12)
head(pt3)

# rename variables
pt3<-dplyr::select(pt3,CoRuLngth=Shape_Leng,CoRuArea=Shape_Area)
head(pt3)

#combine pt data with new names for length
pt2 <- pt2[,-(13:14)] 
pt2@data<-cbind(pt2@data,pt3)
head(pt2@data)

levels(as.factor(as.character(pt2$Hab1)))

levels(as.factor(pt2$Nm_Resil))
levels(as.factor(pt2$Id_resil))
pt2$Nm_Resil3<-as.character(pt2$Nm_Resil)
pt2$Nm_Resil3[pt2$Hab1=="Sand Rubble Coral"]<-"Mixed" 
pt2$Nm_Resil3[pt2$Hab1=="Sand Rubble Seagrass"]<-"Mixed" 
levels(as.factor(as.character(pt2$Nm_Resil)))
str(pt2$Nm_Resil) 

# write out a new shapefile (including .prj component)
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")

writeOGR(pt2, ".", "hab_Resil_Pts_RS", overwrite_layer=T, driver="ESRI Shapefile")

#reset wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")
