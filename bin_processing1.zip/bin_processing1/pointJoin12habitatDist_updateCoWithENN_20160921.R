# Jennifer Selgrath
# Project Seahorse
# Sept 21, 2016

# Updating distance so for rubble is based on ArcGis distance tool and for coral based on ENN tool in Fragstats. That way its always distance of a location, not to itself.
#########################################################################
remove(list=ls())
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)
############################################################
# pull out data to distinguish coral and rubble points
pt<-readOGR(".", "hab_Resil_Pts_RS")
f0p<-pt@data; head(f0p)

f0p<-arrange(f0p,CID)%>%
	dplyr::select(CID,Id_resil)

#version with LEK SG in inner channel and MG on olango
f1p<-read.csv(file="pts_Co_Mg_Sg_minDist.csv",header=T); head(f1p)
f1p<-arrange(f1p,CID)%>%
	dplyr::select(CID,co_minDist:sg_minDist)

f1p2<-merge(f0p,f1p); head(f1p2)

#this has a different length because only coral points
f2p<- read.csv(file="pts_Co_Frag_RS_FromArcGIS.csv",header=T); head(f2p)
f2p<-arrange(f2p,CID)%>%
	dplyr::select(CID,ENN) 
head(f2p)

#merge, keeping all points
f3p<-base::merge(f1p2,f2p,all.x = T)
tail(f3p)

#update co_minDist with ENN for Coral areas
range(f3p$co_minDist)
f3p$co_minDist2<-f3p$co_minDist
f3p$co_minDist[f3p$Id_resil==1]<-f3p$ENN[f3p$Id_resil==1]
head(f3p)

# remove ENN and orig coral distance column
f4p<-dplyr::select(f3p,CID:sg_minDist)
head(f4p)

# write table
write.table(f4p,file="pts_Co_Mg_Sg_minDist2.csv", col.names = T, row.names = F, sep=",")
