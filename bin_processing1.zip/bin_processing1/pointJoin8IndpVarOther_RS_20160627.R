# Jennifer Selgrath
# Project Seahorse, UBC
# May 25, 2016

###########################################
# GOAL: Join random points to other indp data in shapefile format (indp var)
###########################################
# Load packages

# spatial
library(sp)
# library(raster)
library(rgdal)
library(dismo) #map raster on Google Map, species prediction models from raster indp. var
library(dplyr)
library(spatialEco)

############################################################################################
# OBJECTIVE 1: Load and organize files 
############################################################################################
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile # could also use .csv file
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# # load points with hab and resilience data as ESRI shapefile
ogrInfo(".", "hab_Resil_Pts_RS")
pt<-readOGR(".", "hab_Resil_Pts_RS")
head(pt@data)
# str(pt)


############################
# Task 1.2 load shapefiles with indp data 
loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/0most_shp/") #these are for Coral Area
setwd(loc1)

list.files(loc1)

#1. depth/bathymetry # changing to continuous variable
#read in shapefile of depth data
# ogrInfo(".","depth_splinelandshallow_20160726_dis")
v1<-readOGR(".","depth_splinelandshallow_20160726_dis") 

# extract polygon data to points
v1p <- point.in.poly(pt, v1); head(v1p@data)

# convert to data frame
v1p<- as.data.frame(v1p); names(v1p)
v1p<-arrange(v1p,CID)%>%
  dplyr::select(Depth1,Depth_m); head(v1p)

#2. Ecol Zones
# ogrInfo(".","EcologicalZones_FA_Land_20160810"); 
v2<-readOGR(".","EcologicalZones_FA_Land_20160810")

# extract polygon data to points
v2p <- point.in.poly(pt, v2); head(v2p@data)

# convert to data frame
v2p<- as.data.frame(v2p); names(v2p)
v2p<-arrange(v2p,CID)%>%
  dplyr::select(Id_Ezone=Id,EcoZone=Zone); head(v2p)

#3. LongitudeZones 
# ogrInfo(".","longzoneFA_20160525"); 
v3<-readOGR(".","longzoneFA_20160525")

# extract polygon data to points
v3p <- point.in.poly(pt, v3); head(v3p@data)

# convert to data frame
v3p<- as.data.frame(v3p);head(v3p)
v3p<-arrange(v3p,CID)%>%
  dplyr::select(Id_longzn=Id.1); head(v3p)

#4. MPAs
# ogrInfo(".","MPA_FA_20160525_2");
v4<-readOGR(".","MPA_FA_20160525_3"); str(v4@data)

# extract polygon data to points
v4p <- point.in.poly(pt, v4) # does not work if attributes have NA values; 
head(v4p@data)

# convert to data frame
v4p<- as.data.frame(v4p); names(v4p)
v4p<-arrange(v4p,CID)%>%
  dplyr::select(yearEst=YearEst,Id_MPAb=Id_binary, Id_MPAc=Id_MEAT); head(v4p)

#MunicipalWaters
# ogrInfo(".","MunWaterLine3_Polyg6");
v5<-readOGR(".","MunWaterLine3_Polyg6")

# extract polygon data to points
v5p <- point.in.poly(pt, v5); head(v5p@data)

# convert to data frame
v5p<- as.data.frame(v5p); names(v5p)
v5p<-arrange(v5p,CID)%>%
  dplyr::select(Id_MunWtr); head(v5p)


#Distance to mangroves
# ogrInfo(".","mangrove_buf_FA2_20160525");  
v7<-readOGR(".","mangrove_buf_FA2_20160525")

# extract polygon data to points
v7p <- point.in.poly(pt, v7); head(v7p@data)

# convert to data frame
v7p<- as.data.frame(v7p); names(v7p)
v7p<-arrange(v7p,CID)%>%
  dplyr::select(Id_dMg,distMg=distance); head(v7p)

#Distance to seagrass areas
# ogrInfo(".","seagrass_buf_FA2_20160525");
v8<-readOGR(".","seagrass_buf_FA2_20160525")

# extract polygon data to points
v8p <- point.in.poly(pt, v8); head(v8p@data)

# convert to data frame
v8p<- as.data.frame(v8p); names(v8p)
v8p<-arrange(v8p,CID)%>%
  dplyr::select(Id_dSg,distSg=distance); head(v8p)

# var.names<-c("Depth","EcoZone","LongZone","MPA","MunWater","dRiver", "dMang","dSeagrs")

####################################
# join new tables to original pt table
head(pt@data)
pt@data=cbind(pt@data,v1p,v2p,v3p,v4p,v5p,v7p,v8p) # v6p,
head(pt@data)

loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc1)

# write out a new shapefile (including .prj component)
writeOGR(pt, ".", "IndpVarOther_Pts_RS", overwrite_layer=T, driver="ESRI Shapefile")

# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")




