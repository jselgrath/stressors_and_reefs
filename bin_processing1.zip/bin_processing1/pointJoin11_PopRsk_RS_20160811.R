# Jennifer Selgrath
# August 11, 2016
# Ch4

# GOAL: Load raster with population risk estimates from study area

# library(raster)
# library(spatial)
# library(ggplot2)
# library(spatialEco)
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

#read in shapefile of random point with resilience data
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) 
head(pts@data)
# str(pts)

######################################
# Stack and organize the rasters of fishing effort

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/population")
loc<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/population"

# list.files(loc)

files<-list.files(pattern=c(".tif$"))
head(files)

files2<-files[2] 
# PopRskDecay has land, but ignore...
#PopRsk2 is just area with land masked out

s <- stack(files2)
names(s)
nl <- nlayers(s)
dataType(s)

# plot(s[[1]])


# Calculate max for raster 
# or better for values within the range of the samples??

maxRsk<-s[[1]]@data@max 
#88 for old method. 6.17 for new method

###########################################
#Extract Raster Variables to Point Data
d1<-data.frame(coordinates(pts),
               pts$CID,
               extract(s,pts))

names(d1)<-c("x","y","CID","PopRskDecay")

head(d1)
# str(d1)

##########################
# Calculate normalized variables (value at a site/max value), See Maynard et al 2015

# set NAs to 0 (sometimes showing up as 128)
d1$PopRskDecay[d1$PopRskDecay>88]<-0
d1$PopRskDecay[is.na(d1$PopRskDecay)]<-0
head(d1)

d2<-d1


d2$PopRsk.Nrm=d2$PopRskDecay/maxRsk

# Round to 4 decimal places
tail(d2)

d2[,5] <-round(d2[,5],4)
tail(d2)

qplot(d2$PopRsk.Nrm)

# names(d2)<-c("x1","x2","CID","PopRsk2","PopRsk.Nrm")
# tail(d2)

########################
#export table
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only") #results file

write.table(d2,file="pts_PopRsk_Norm.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 






