# Jennifer Selgrath
# Project Seahorse, UBC
# May 30, 2016

###########################################
# GOAL: Join random points to fragstat data (indp var)
# updated Sept 27, 2016 to add other metrics
###########################################
# Load packages

# # spatial
# library(sp)
# library(raster)
# library(rgdal)
# library(dismo) #map raster on Google Map, species prediction models from raster indp. var
# library(spatialEco)



####################################################################
# OBJECTIVE 1: Load and organize files 
############################################################################################
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile # could also use .csv file
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# # load points (with 2010 fishing data attached) from csv not ESRI shapefile
# ogrInfo(".", "hab_Resil_Pts_RS")
# pts<-readOGR(".", "hab_Resil_Pts_RS")
# head(pts@data)
# str(pts)

# test<-as.data.frame(pts)


############################
# Task 1.2 load shapefile with indp data from fragstats
# loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/landscape/") #these are for Coral Area
# setwd(loc1)

##################################
# Task 1.3 load shapefile with landscape variables
# ogrInfo(".", "coralAreaFrag_20160527")
# frag<-readOGR(".", "coralAreaFrag_20160527")
# frag<-readOGR(".", "CoRu_Frag_20160927")

# in GIS run model "Ch4_DistToHabitat/CoRuFrag_ToPts.tbx"

frag<-readOGR(".", "CoRu_Frag_Pts") # Joind with 1 m buffer in ArcGIS because missing some here
head(frag@data)
# plot
# plot(frag) #
##############
###########################################
# Extract  Variables to Point Data
# intersect points in polygon
# pts2 <- point.in.poly(pts, frag)
# str(pts2)

# convert to data frame, keeping your data
pts2<- as.data.frame(frag)
head(pts2)


pts3<-dplyr::select(pts2,CID=PtID,GRIDCODE,AREA:ENN_1); head(pts3)

########################333
#export table
setwd(loc) #results folder
write.table(pts3,file="pts_Frag_RS.csv", sep=",", col.names=T, row.names=F)

# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")

