# Jennifer Selgrath
# Project Seahorse, UBC
# July 31, 2016

###########################################
# GOAL: Join random points to other indp data in shapefile format (indp var)
###########################################
# # Load packages
# 
# # spatial
# library(sp)
# # library(raster)
# library(rgdal)
# library(dismo) #map raster on Google Map, species prediction models from raster indp. var
# library(dplyr)
# library(raster)


############################################################################################
# OBJECTIVE 1: Load and organize files 
############################################################################################
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile # could also use .csv file
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# # load points with hab and resilience data as ESRI shapefile
# ogrInfo(".", "hab_Resil_Pts_RS")
pt1<-readOGR(".", "hab_Resil_Pts_RS")
head(pt1@data)
str(pt1)

# drop unneeded columns from points
pt<-pt1[,-(2:ncol(pt1))]
head(pt@data)
names(pt@data)<-"CID"

test<-pt@data

#####################
# Task 1.2 Load rasters

############################
# Task 1.2 load rasters with fishing data

loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/distTownBgyRiver/")
setwd(loc1)


##################################
# Task 1.3 stack and organize the rasters 

# list of files 
# ?be sure they are "float" format in ArcGIS
# files = dir(loc1)
files = list.files(pattern='.tif$')

s <- stack(files)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('distBgy','distTown', 'distRiver') #dist cebu
names(s) = new_names


###########################################
#Extract Raster Variables to Point Data
d1<-data.frame(coordinates(pt),
               pt$CID,
               extract(s,pt))

names(d1)<-c("x","y","CID",new_names)
head(d1)
tail(d1)
str(d1)


#######################
# Extract Dist to Market Values
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/distMarket/")
setwd(loc2)

r<-raster('EucDistPasil2.tif')

head(d1)

# link to points
d2<-data.frame(pt$CID,
               extract(r,pt))
head(d2)
names(d2) = c('CID','distMarket')

d1<-dplyr::arrange(d1,CID)
d2<-dplyr::arrange(d2,CID)

d3<-cbind.data.frame(d1,d2)
head(d3)

d3<-d3[,c(1:6,8)] #drop 2nd CID column


f1<-function (x) round(x/1000,2)
d3$distBgy.km<-f1(d3$distBgy)
d3$distTown.km<-f1(d3$distTown)
d3$distRiver.km<-f1(d3$distRiver)
d3$distMarket.km<-f1(d3$distMarket)

head(d3)
  
d4<-dplyr::select(d3,x,y,CID,distBgy.km,distTown.km,distMarket.km,distRiver.km)
head(d4)

########################
#export table
setwd(loc) #results file
# write.table(d2,file="pts_HabResilFishing.csv", sep=",", col.names=T, row.names=F)
write.table(d4,file="pts_distBgyTownRiver.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 


