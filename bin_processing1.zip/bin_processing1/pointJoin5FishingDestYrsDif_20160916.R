# Jennifer Selgrath
# Sept 16, 2016
# Ch4

# GOAL: Load differences in dest fishing effort estimates from all years

library(raster)
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

ogrInfo(".","hab_Resil_Pts_RS")
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) #read in shapefile of random point with resilience data

# str(pts)

#read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/coralrubble")

CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

#return wd
setwd(loc)

######################################
# Stack and organize the rasters of fishing effort

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/Dest_dif_CoralArea")
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/Dest_dif_CoralArea"

list.files(loc3)

files<-list.files(pattern=".tif$")
head(files)

s <- stack(files)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('destDif_00_90','destDif_10_00','destDif_10_80','destDif_10_90', 'destDif_90_80')
names(s) = new_names

plot(s[[1]])


###########################################
#Extract Raster Variables to Point Data
d1<-data.frame(coordinates(pts),
               pts$CID,
               extract(s,pts))

names(d1)<-c("x","y","CID",new_names)

tail(d1)
str(d1)

########################
#export table
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only") #results file

write.table(d1,file="pts_FishingYrsDest_Dif.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 




