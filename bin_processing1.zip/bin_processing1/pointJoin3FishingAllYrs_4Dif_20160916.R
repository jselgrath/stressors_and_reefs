# Jennifer Selgrath
# Sept 16, 2016
# Ch4

# GOAL: Load difference in fishing effort (estimates from all years(normalized)
library(raster)
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

#read in shapefile of random point with resilience data
ogrInfo(".","hab_Resil_Pts_RS")
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) 
# str(pts)
# length(unique(pts@data$CID))

######################################
# Stack and organize the rasters of fishing effort

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/All_dif_CoralArea") 

loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/All_dif_CoralArea"


list.files(loc3)

files<-list.files(pattern=c('.tif$','all'))

s <- stack(files)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('allDif_00_90','allDif_10_00','allDif_10_80','allDif_10_90', 'allDif_90_80')
names(s) = new_names

plot(s[[1]])



###########################################
#Extract Raster Variables to Point Data
d1<-data.frame(coordinates(pts),
               pts$CID,
               extract(s,pts))

names(d1)<-c("x","y","CID",new_names)

tail(d1)

########################
#export table
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only") #results file

write.table(d1,file="pts_FishingYrs_Dif.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 




