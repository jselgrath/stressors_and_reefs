# Jennifer Selgrath
# June 30, 2016
# Ch4

# GOAL: Load dest fishing effort estimates from all years

library(raster)
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

ogrInfo(".","hab_Resil_Pts_RS")
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) #read in shapefile of random point with resilience data

# str(pts)

#read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/coralrubble")

CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

#return wd
setwd(loc)

######################################
# Stack and organize the rasters of fishing effort

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates")
loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates"

list.files(loc3)

files<-list.files(pattern=c(".tif$","est_dayYr_dest1"))
files2<-files[37:42]
head(files2)

s <- stack(files2)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('dest1960','dest1970', 'dest1980','dest1990','dest2000',"dest2010")

names(s) = new_names

# Mask rasters so only evaluating fishnig effort in coral areas
s2<-mask(s, CA) #,inverse=TRUE
str(s2)
str(s)

# plot(s[[1]])
# plot(s2[[1]])


# Calculate max for each year for entire raster 
# or better for values within the range of the samples??
mx.yr<-vector('numeric')
for (i in 1:6){
  val<-s2[[i]]@data@max
  max<-round(val,0)
  mx.yr<-rbind(mx.yr,max)
}

mx.yr
mx.dest<-max(mx.yr)

###########################################
#Extract Raster Variables to Point Data
d1<-data.frame(coordinates(pts),
               pts$CID,
               extract(s,pts))

names(d1)<-c("x","y","CID",new_names)

tail(d1)
str(d1)

##########################
# Calculate normalized variables (value at a site/max value), See Maynard et al 2015
# NOTE: I Confirmed and NAs are in places with no fishing info...

######## these ones are normalized by the year they were in ###########
d2<-d1
d2$dest1960.Nrm=d2$dest1960/mx.yr[1]
d2$dest1970.Nrm=d2$dest1970/mx.yr[2]
d2$dest1980.Nrm=d2$dest1980/mx.yr[3]
d2$dest1990.Nrm=d2$dest1990/mx.yr[4]
d2$dest2000.Nrm=d2$dest2000/mx.yr[5]
d2$dest2010.Nrm=d2$dest2010/mx.yr[6]

######## these ones are normalized by all years ###########
d2$dest1960.NrmA=d2$dest1960/mx.dest
d2$dest1970.NrmA=d2$dest1970/mx.dest
d2$dest1980.NrmA=d2$dest1980/mx.dest
d2$dest1990.NrmA=d2$dest1990/mx.dest
d2$dest2000.NrmA=d2$dest2000/mx.dest
d2$dest2010.NrmA=d2$dest2010/mx.dest

# Round to 4 decimal places
tail(d2)
names(d2)
d2[,c(4:21)] <-round(d2[,c(4:21)],4)
tail(d2)

qplot(d2$dest2010.NrmA)

########################
#export table
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only") #results file

write.table(d2,file="pts_FishingYrsDest_Norm.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 




