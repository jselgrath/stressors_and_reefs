# Jennifer Selgrath
# June 27,2016
# Coral resilience to fishing impacts

#####################################
# GOAL: find mean and min values for distance from coral patches to mangrove patches

#Data from ArcGIS Generate near table, Toolbox: MgSG_Distance_20160627
###################################

###########################
#LoadData
########################
remove(list=ls())

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/prox")

# distance between coral patches and seagrass patches or mangrove patches
# remote sensing data only
# sg all = anything with sg

# co: dist to sg, mg
d1<- read.csv(file = "RS_CoRu_MG_dist_ANYm.csv", header = T, stringsAsFactors = F, strip.white = TRUE, na.strings = c("NA","","na"))

head(d1)
length(unique(d1$IN_FID))
length(unique(d1$NEAR_FID))
sort(unique(d1$NEAR_FID))

#remove excess text
d1$NEAR_FC<-"mangroves"

# d1$NEAR_FC<-gsub("C:\\Users\\Jenny\\Dropbox\\1PhD\\R.projects\\Ch4\\Resilience\\data\\prox\\","",d1$NEAR_FC,fixed=T)
head(d1)

levels(as.factor(d1$NEAR_FC))
length(unique(d1$IN_FID))
length(unique(d1$NEAR_FID))

# load Mangrove polygons to get data
ogrInfo(".","MGall_smplfd_20160628")
mg<-readOGR(".","MGall_smplfd_20160628",stringsAsFactors=TRUE) 
mg@data$NEAR_FID = rownames(mg@data)
head(mg@data)

# merge area data from mg polygons with subsetted distance data (mg all only)
mg2<-data.frame(mg@data)
head(mg2)

length(unique(mg2$NEAR_FID))

str(d1)

mg3 = merge.data.frame(d1,mg2, all=FALSE, by = "NEAR_FID")
tail(mg3)

#make adjacent patches have a very low distance to address dividing by 0 issues
mg3$NEAR_DIST[mg3$NEAR_DIST==0]<-.0001 
mg3$proxInt<-mg3$Shape_Area/(mg3$NEAR_DIST^2) #(MG area)/(dist to co/ru patch^2)

names(mg3)

length(levels(as.factor(mg3$IN_FID)))

# summarize 
d3<-ddply(mg3,c("IN_FID","NEAR_FC"),summarize, #
          mgNEARn=length(NEAR_DIST),
          mgNEAR_DISTmin=round(min(NEAR_DIST),2),
          mgNEAR_DISTu=round(mean(NEAR_DIST, na.omit=T),2),
          mgNEAR_DISTsd=round(sd(NEAR_DIST),2),
          mgNEAR_DISTse=round(mgNEAR_DISTsd/sqrt(mgNEARn),2),
          mgProx=round(sum(proxInt),3))

head(d3)

range(d3$mgProx)

length(levels(as.factor(d3$IN_FID)))

is.na(d3$mgNEARn)
is.na(d3$mgNEAR_DISTmin)


#######################
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
write.table(d3,file="MgallProx1_RS.csv", sep=",", col.names=T, row.names=F)

# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")
