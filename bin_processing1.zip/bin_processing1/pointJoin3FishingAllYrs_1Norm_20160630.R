# Jennifer Selgrath
# June 30, 2016
# Ch4

# GOAL: Load fishing effort estimates from all years
library(raster)
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

#read in shapefile of random point with resilience data
ogrInfo(".","hab_Resil_Pts_RS")
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) 
# str(pts)
# length(unique(pts@data$CID))

#read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/coralrubble")

CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

#return wd
setwd(loc)


######################################
# Stack and organize the rasters of fishing effort

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates") 

loc3<-"C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing/EffortEstimates"


list.files(loc3)

files<-list.files(pattern=c('.tif$','all'))
files2<-files[13:18]
files2

s <- stack(files2)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('all1960','all1970', 'all1980','all1990','all2000',"all2010")

names(s) = new_names

# plot(s[[1]]) # effort 1960
# str(s[[1]])

# Mask rasters so only evaluating fishnig effort in coral areas
s2<-mask(s, CA) #,inverse=TRUE
str(s2)
str(s)

plot(s[[1]])
plot(s2[[1]])

# Calculate max for each year for Coral and Rubble Area only
# or better for values within the range of the samples??
mx.yr<-vector('numeric')
for (i in 1:6){
  val<-s2[[i]]@data@max
  max<-round(val,0)
  mx.yr<-rbind(mx.yr,max)
}

mx.yr
mx.all<-max(mx.yr)

###########################################
#Extract Raster Variables to Point Data
d1<-data.frame(coordinates(pts),
               pts$CID,
               extract(s,pts))

names(d1)<-c("x","y","CID",new_names)

tail(d1)
# str(d1)

##########################
# Calculate normalized variables (value at a site/max value), See Maynard et al 2015
# NOTE: I Confirmed and NAs are in places with no fishing info...

######## these ones are normalized by the year they were in ###########
d2<-d1
d2$all1960.Nrm=d2$all1960/mx.yr[1]
d2$all1970.Nrm=d2$all1970/mx.yr[2]
d2$all1980.Nrm=d2$all1980/mx.yr[3]
d2$all1990.Nrm=d2$all1990/mx.yr[4]
d2$all2000.Nrm=d2$all2000/mx.yr[5]
d2$all2010.Nrm=d2$all2010/mx.yr[6]

######## these ones are normalized by all years ###########
d2$all1960.NrmA=d2$all1960/mx.all
d2$all1970.NrmA=d2$all1970/mx.all
d2$all1980.NrmA=d2$all1980/mx.all
d2$all1990.NrmA=d2$all1990/mx.all
d2$all2000.NrmA=d2$all2000/mx.all
d2$all2010.NrmA=d2$all2010/mx.all

# Round to 4 decimal places
d2[,c(7:21)] <-round(d2[,c(7:21)],4) #the "-1" excludes column 1
head(d2)



qplot(d2$all2010.Nrm)

########################
#export table
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only") #results file

write.table(d2,file="pts_FishingYrs_Norm.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 




