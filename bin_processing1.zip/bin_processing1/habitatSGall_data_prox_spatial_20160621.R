# Jennifer Selgrath
# June 21,2016
# Coral resilience to fishing impacts

#####################################
# GOAL: connect mean distance and prox values to sg polygons and assign polygon values to random points located within them

#Data from ArcGIS Generate near table
###################################
library (plyr)
library(sp)
library(rgdal)
library(maptools)
library(dismo)
library(spatialEco)

###########################
#LoadData
########################
remove(list=ls())

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")

# distance between coral patches and seagrass patches or mangrove patches
# remote sensing data only
# sg est as only med/high or anything with sg
d1<- read.csv(file = "SGallProx1_RS.csv", header = T, stringsAsFactors = F, strip.white = TRUE, na.strings = c("NA","","na"))

head(d1)

##############
# load coral and rubble area polygons
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/prox")

# ogrInfo(".","CoRu_smplfd_20160628")
coral<-readOGR(".","CoRu_smplfd_20160628")
coral@data$IN_FID = as.numeric(rownames(coral@data))
head(coral@data)
str(coral@data)


# merge coral polygon data with isolation and prox data
coral@data = left_join(coral@data,d1, by = "IN_FID")
head(coral@data)

names(coral@data)
nms<-c("Id_resil","Nm_Resil","Shape_Leng","Shape_Area","IN_FID", "NEAR_FC", "sg_nNear","sg_minDist","sg_uDist","sg_sdDist","sg_seDist", "sgProx")

# coral2<-coral
names(coral@data)<-nms
head(coral)


qplot(coral@data$sgProx)


# write out a new shapefile (including .prj component) of corals and sg area
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
writeOGR(coral, ".", "CoRu_SGaProxy_RS", overwrite_layer=T,driver="ESRI Shapefile")



###########
# Join coral polygon data with random points
###########

# load points from ESRI shapefile # could also use .csv file
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# # load points with hab and resilience data as ESRI shapefile
# ogrInfo(".", "hab_Resil_Pts_RS")
pt1<-readOGR(".", "hab_Resil_Pts_RS")
head(pt1@data)
names(pt1@data)

# drop unneeded columns from points
pt<-pt1[,-(2:15)]
head(pt@data)

# extract polygon data to points
pt2 <- point.in.poly(pt,coral); head(pt2@data)

# convert to data frame
pt3<- as.data.frame(pt2); names(pt3)
pt3<- arrange(pt3,CID)%>%
  dplyr::select(CID,sgNEAR_FC=NEAR_FC,sg_nNear:sgProx); head(pt3) #check against FID with IN_FID

####################################
# join new tables to original pt table
# head(pt@data)
# pt@data=cbind(pt@data,pt3)
# head(pt@data)

loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc1)

# write out a new shapefile (including .prj component)
writeOGR(pt2, ".", "ProxSGall_Pts_RS", overwrite_layer=T,driver="ESRI Shapefile")

#save as csv
d2<-pt@data
write.table(pt3,file="pts_ProxSGall_RS.csv",col.names = T,row.names=F,sep=",")


# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")

