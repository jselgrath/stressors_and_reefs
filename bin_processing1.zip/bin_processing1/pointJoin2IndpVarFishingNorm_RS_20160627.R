# Jennifer Selgrath
# Project Seahorse, UBC
# June 27, 2016 

###########################################
# GOAL: Join random points to fisheries data and normalize fishing frequency and intensity
###########################################
# Load packages

# spatial
library(sp)
library(rgdal)
library(dismo) #map raster on Google Map, species prediction models from raster indp. var
library(ggplot2)


######################
# Area with Coral/Rubble only (CA = coral area)
########################################################################
####  OBJECTIVE 1: Load and organize files 
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

#read in shapefile of random point with resilience data
# ogrInfo(".","hab_Resil_Pts_RS")
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) 

# str(pts)

#read in shapefile of coral/rubble area only
loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing_cum")

CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

#return wd
setwd(loc)

############################
# Task 1.2 load rasters with fishing data
library(raster)
loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/0fishing2010/")
setwd(loc1)

##################################
# Task 1.3 stack and organize the rasters 

# list of files 
# ?be sure they are "float" format in ArcGIS
# files = dir(loc1)
files = list.files(pattern='.tif$')
# files

s <- stack(files)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('allEffort2010','nonDestEffort2010', 'destEffort2010','divGen2010','divSpec2010',"SIGen2010")
names(s) = new_names

# plot
# plot(s[[1]]) # effort


# set 99,999 to NA 
# http://www.inside-r.org/packages/cran/raster/docs/calc
fun <- function(x) { x[x==99999] <- NA; return(x) }
s2 <- calc(s, fun)
# plot(s2[[1]])
# range(s2[[1]])

# Mask rasters so only evaluating fishnig effort in coral areas
s3<-mask(s2, CA) #,inverse=TRUE
str(s3)



################
# Calculate max for each raster 
# or better for values within the range of the samples??
mx<-vector('numeric')
for (i in 1:6){
  val<-s3[[i]]@data@max
  max<-round(val,0)
  mx<-rbind(mx,max)
}

mx


###########################################
#Extract Raster Variables to Point Data
d1<-data.frame(coordinates(pts),
               pts$CID,
               extract(s3,pts))

names(d1)<-c("x","y","CID",new_names)

tail(d1)
str(d1)

length(unique(d1$CID))

##########################
# Calculate normalized variables (value at a site/max value), See Maynard et al 2015
##########################
d1$freqAll.Norm<-round(d1$allEffort2010/mx[1],4)
d1$freqAll.Norm

d1$freqDest.Norm<-round(d1$destEffort2010/mx[2],4)
d1$freqDest.Norm

d1$freqNonDest.Norm<-round(d1$nonDestEffort2010/mx[3],4)
d1$freqNonDest.Norm

# combine frequency and impact
d1$impact.Norm<-d1$freqAll.Norm+d1$freqDest.Norm
d1$impact.Norm

qplot(d1$impact.Norm)


########################
#export table
setwd(loc) #results file
# write.table(d2,file="pts_HabResilFishing.csv", sep=",", col.names=T, row.names=F)
write.table(d1,file="pts_FishingImpactNorm.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 

