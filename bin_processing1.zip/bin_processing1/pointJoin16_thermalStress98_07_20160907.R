# Jennifer Selgrath
# Project Seahorse, UBC
# September 7, 2016 

###########################################
# GOAL: Join random points to thermal stress data
###########################################
# Load packages

# spatial
library(sp)
library(rgdal)
library(dismo) #map raster on Google Map, species prediction models from raster indp. var
library(ggplot2)


######################
# Area with Coral/Rubble only (CA = coral area)
########################################################################
####  OBJECTIVE 1: Load and organize files 
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile 
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

#read in shapefile of random point with resilience data
# ogrInfo(".","hab_Resil_Pts_RS")
pts<-readOGR(".","hab_Resil_Pts_RS",stringsAsFactors=TRUE) 

# str(pts)

#read in shapefile of coral/rubble area only
# loc2=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/fishing_cum")
# 
# CA<-readOGR(loc2,"CoralRubArea",stringsAsFactors=TRUE) 

#return wd
setwd(loc)

############################
# Task 1.2 load rasters with fishing data
library(raster)
loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/risks/global")
setwd(loc1)

##################################
# Task 1.3 stack and organize the rasters 

# list of files 
# ?be sure they are "float" format in ArcGIS
# files = dir(loc1)
files = list.files(pattern='.tif$')
files

files2<-files[4]
files2
s <- stack(files2)
names(s)
nl <- nlayers(s)
dataType(s)

# change names to something better
new_names = c('therm_98_07')
names(s) = new_names
s

plot(s[[1]]) #
# plot(CA) #Focal Area

d1<-data.frame(coordinates(pts),
							 pts$CID,
							 extract(s,pts))

names(d1)<-c("x","y","CID",new_names)

tail(d1)
str(d1)

length(unique(d1$CID))

########################
#export table
setwd(loc) #results file
# write.table(d2,file="pts_HabResilFishing.csv", sep=",", col.names=T, row.names=F)
write.table(d1,file="pts_ThermStress.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 

