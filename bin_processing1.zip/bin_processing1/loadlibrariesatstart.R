# Jennifer Selgrath
# 20160818

# load libraries for project

# library(devtools)
# devtools::install_github("sjPlot/devel")
# devtools::install_github("sjPlot/sjmisc")

# Set libraries
library(plyr)
library(dplyr)
library(tidyr)
library(rgdal)
library(dismo)
library(maptools)
library(lme4)
library(car)  # function Anova - correct checking on models
library(lsmeans)
library(ggplot2)
library(sjPlot)
library(RColorBrewer)
library(MuMIn) # for dredge, though not using
library(spatialEco)
library(spatial)
library(arm)
library(lazyeval)

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")
