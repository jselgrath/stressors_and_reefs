# Jennifer Selgrath
# June 27,2016
# Coral resilience to fishing impacts

#####################################
# GOAL: connect mean distance and prox values to mg polygons and assign polygon values to random points located within them

#Data from ArcGIS Generate near table
###################################
library (plyr)
library(sp)
library(rgdal)
library(maptools)
library(dismo)
library(spatialEco)

###########################
#LoadData
########################
remove(list=ls())

setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")

# distance between coral patches and mangrove patches
# remote sensing data only
# mg est as only med/high or anything with mg
d1<- read.csv(file = "MGallProx1_RS.csv", header = T, stringsAsFactors = F, strip.white = TRUE, na.strings = c("NA","","na"))

head(d1)

##############
# load coral and rubble area polygons
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/prox")

# ogrInfo(".","CoRu_smplfd_20160628")
coral<-readOGR(".","CoRu_smplfd_20160628",stringsAsFactors=TRUE) 
coral@data$IN_FID = as.numeric(rownames(coral@data))
head(coral@data)
str(coral@data)

# merge coral polygon data with isolation and prox data
coral@data = left_join(coral@data,d1, by = "IN_FID")
names(coral@data)
nms<-c("Id_resil","Nm_Resil","Shape_Leng","Shape_Area","IN_FID", "NEAR_FC", "mg_nNear","mg_minDist","mg_uDist","mg_sdDist","mg_seDist", "mgProx")

names(coral@data)<-nms
head(coral)

# set NAs to 0 or other value as needed
# is.na(coral@data$mg_nNear)
# is.na(coral@data$mgProx)

coral@data$mg_minDistKm<-coral@data$mg_minDist/1000
coral@data$mg_minDistKm<-round(coral@data$mg_minDistKm,2)

# write out a new shapefile (including .prj component) of corals and mg area
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
writeOGR(coral, ".", "CoRu_MGaProxy_RS", overwrite_layer=T,driver="ESRI Shapefile")

###########
# Join coral polygon data with random points
###########

# load points from ESRI shapefile # could also use .csv file
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# # load points with hab and resilience data as ESRI shapefile
# ogrInfo(".", "hab_Resil_Pts_RS")
pt1<-readOGR(".", "hab_Resil_Pts_RS")
head(pt1@data)
names(pt1@data)

# drop unneeded columns from points
pt<-pt1[,-(2:15)]
head(pt1@data)

# extract polygon data to points
pt2 <- point.in.poly(pt1,coral); head(pt2@data)

# convert to data frame
pt3<- as.data.frame(pt2); names(pt3)
pt3<- arrange(pt3,CID)%>%
  dplyr::select(CID,mgNEAR_FC=NEAR_FC,mg_nNear:mgProx); head(pt3)

####################################
# write out a new shapefile (including .prj component)
loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc1)

writeOGR(pt2, ".", "ProxMG_Pts_RS", overwrite_layer=T,driver="ESRI Shapefile")

#save as csv
# d2<-pt2@data
write.table(pt3,file="pts_ProxMG_RS.csv",col.names = T,row.names=F,sep=",")


# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")

