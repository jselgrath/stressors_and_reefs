# Jennifer Selgrath
# Project Seahorse, UBC
# August 3, 2016

###########################################
# GOAL: Join random points to output from fishing and fragstat joins
###########################################


#########################################################################
# Load and organize files 
#########################################################################
remove(list=ls())
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# # load points with normalized fishing by decade'
d1<-read.csv(file="pts_FishingYrs_Norm.csv", header=T)
head(d1)

# calculate cumulative impact from all fishing effort by adding normalized values across various subsets of gears
d2<-mutate(d1,
           # std by yearly max
           fYr00=all2010.Nrm, 
           fYr10=all2010.Nrm+all2000.Nrm, 
           fYr20=all2010.Nrm+all2000.Nrm+all1990.Nrm, 
           fYr30=all2010.Nrm+all2000.Nrm+all1990.Nrm+all1980.Nrm, 
           fYr40=all2010.Nrm+all2000.Nrm+all1990.Nrm+all1980.Nrm+all1970.Nrm, 
           fYr50=all2010.Nrm+all2000.Nrm+all1990.Nrm+all1980.Nrm+all1970.Nrm+all1960.Nrm,
           
           # std by max for all years
           fYr00A=all2010.NrmA, 
           fYr10A=all2010.NrmA+all2000.NrmA, 
           fYr20A=all2010.NrmA+all2000.NrmA+all1990.NrmA, 
           fYr30A=all2010.NrmA+all2000.NrmA+all1990.NrmA+all1980.NrmA, 
           fYr40A=all2010.NrmA+all2000.NrmA+all1990.NrmA+all1980.NrmA+all1970.NrmA, 
           fYr50A=all2010.NrmA+all2000.NrmA+all1990.NrmA+all1980.NrmA+all1970.NrmA+all1960.NrmA,
					 
					 # std by max for all years with 10 year lag
					 fYrLag10A=all2000.NrmA, 
					 fYrLag20A=all2000.NrmA+all1990.NrmA, 
					 fYrLag30A=all2000.NrmA+all1990.NrmA+all1980.NrmA, 
					 fYrLag40A=all2000.NrmA+all1990.NrmA+all1980.NrmA+all1970.NrmA, 
					 fYrLag50A=all2000.NrmA+all1990.NrmA+all1980.NrmA+all1970.NrmA+all1960.NrmA)%>%
  dplyr::select(CID,fYr00:fYrLag50A)

head(d2)

qplot(d2$fYr50)
qplot(d2$fYr50A)
qplot(d2$fYrLag50A)

#export table
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only") 

write.table(d2,file="pts_FishingYrsCumulative.csv", sep=",", col.names=T, row.names=F)

# reset wd
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/") 
