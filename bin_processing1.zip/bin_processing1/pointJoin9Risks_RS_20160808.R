# Jennifer Selgrath
# Project Seahorse, UBC
# June 28, 2016

###########################################
# GOAL: Join random points to other reefs at risk data in shapefile format (indp var)
###########################################
# Load packages

# spatial
library(sp)
# library(raster)
library(rgdal)
library(dismo) #map raster on Google Map, species prediction models from raster indp. var
library(dplyr)


############################################################################################
# OBJECTIVE 1: Load and organize files 
############################################################################################
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile # could also use .csv file
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# # load points with hab and resilience data as ESRI shapefile
# ogrInfo(".", "hab_Resil_Pts_RS")
pt1<-readOGR(".", "hab_Resil_Pts_RS")
head(pt1@data)

# drop unneeded columns from points
pt<-pt1[,-(2:15)]
head(pt@data)


############################
# Task 1.2 load shapefiles with indp risk data 
# Source: World Resources Institute, Reefs at Risk Revisited, 2011 (contact lauretta@wri.org or kreytar@wri.org)

loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/risks/risks_19x22/") 
setwd(loc1)
list.files(loc1)

# NOTE:
# - For the individual local threat layers, values of 0 indicate low threat, 100 indicate medium threat, and 1000 indicate high threat.
# - For the integrated local threat layers, values of 0 indicate low threat, 100 indicate medium threat, 1000 indicate high threat, and 1500 indicate very high threat.


#1. Coastal Development
ogrInfo(".","rf_cd_poly_FA") 
v1<-readOGR(".","rf_cd_poly_FA") #read in shapefile 

# extract polygon data to points
v1p <- point.in.poly(pt, v1); head(v1p@data)

# convert to data frame
v1p<- as.data.frame(v1p); names(v1p)
v1p<-arrange(v1p,CID)%>%
  dplyr::select(RskCstDev=THREAT); head(v1p)

#2. Integrated Local Threat
ogrInfo(".","rf_int_loc_poly_FA"); v2<-readOGR(".","rf_int_loc_poly_FA")

# extract polygon data to points
v2p <- point.in.poly(pt, v2); head(v2p@data)

# convert to data frame
v2p<- as.data.frame(v2p); names(v2p)
v2p<-arrange(v2p,CID)%>%
  dplyr::select(RskIntgr=THREAT); head(v2p)

#3. Marine-based Pollution and Damage
ogrInfo(".","rf_mar_poly_FA"); v3<-readOGR(".","rf_mar_poly_FA")

# extract polygon data to points
v3p <- point.in.poly(pt, v3); head(v3p@data)

# convert to data frame
v3p<- as.data.frame(v3p); names(v3p)
v3p<-arrange(v3p,CID)%>%
  dplyr::select(RskMrPlDmg=THREAT); head(v3p)

#4. Overfishing and Destructive Fishing
ogrInfo(".","rf_ovf_adj_poly_FA");v4<-readOGR(".","rf_ovf_adj_poly_FA")

# extract polygon data to points
v4p <- point.in.poly(pt, v4); head(v4p@data)
v4p<- as.data.frame(v4p); names(v4p) # convert to data frame
v4p<-arrange(v4p,CID)%>%
  dplyr::select(RskFsng=THREAT); head(v4p)


#5.Watershed-Based Pollution
ogrInfo(".","rf_sed_poly_FA");v5<-readOGR(".","rf_sed_poly_FA")

# extract polygon data to points
v5p <- point.in.poly(pt, v5); head(v5p@data)

# convert to data frame
v5p<- as.data.frame(v5p); names(v5p)
v5p<-arrange(v5p,CID)%>%
  dplyr::select(RskWtrShdPl=THREAT); head(v5p)

####################################
# join new tables to original pt table
pt@data=cbind(pt@data,v1p,v2p,v3p,v4p,v5p)
head(pt@data)

loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc1)

# write out a new shapefile (including .prj component)
writeOGR(pt, ".", "Risks_Pts_RS", overwrite_layer=T, driver="ESRI Shapefile")

# write .csv
pt2<-pt@data

write.table(pt2,file="pts_Risk_RS.csv",row.names = F,col.names = T,sep=",")

# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")




