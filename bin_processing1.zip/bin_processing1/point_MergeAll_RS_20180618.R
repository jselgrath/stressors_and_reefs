# Jennifer Selgrath
# Project Seahorse, UBC
# June 27, 2016

###########################################
# GOAL: Join random points to output from fishing and fragstat joins
###########################################

#########################################################################
# Load and organize files 
#########################################################################
remove(list=ls())
# version 1 - from ESRI shapefile # could also use .csv file
loc=("C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/results/RS_only")
setwd(loc)

# # load points with hab, resilience, and some indp data as ESRI shapefile
# ogrInfo(".", "IndpVarOther_Pts_RS")
pt<-readOGR(".", "IndpVarOther_Pts_RS")
head(pt@data)

# length(unique(pt@data$CID))

# load csv points from fishing, fragstats, distance, and prox data
# here not data from categorical fishing impact script
f1p<-read.csv(file="pts_FishingImpactNorm.csv",header=T)
head(f1p)
f1p<-arrange(f1p,CID)%>%
  dplyr::select(allEffort2010:impact.Norm); head(f1p) #destFEc,impact

f2p<-read.csv(file="pts_Frag_RS.csv",header=T); head(f2p)
f2p<-arrange(f2p,CID)%>%
  dplyr::select(FragGrid=GRIDCODE,AREA,PARA,ENN,SHAPE=SHAPE_1,FRAC,CONTIG); head(f2p)

#version with LEK SG in inner channel and MG on olango
# coral uses dist from fragstats, rubble uses dist from ArcGIS
f3p<-read.csv(file="pts_Co_Mg_Sg_minDist2.csv",header=T); head(f3p)
f3p<-arrange(f3p,CID)%>%
	dplyr::select(co_minDist:sg_minDist)

# f5p<-read.csv(file="pts_Risk_RS.csv", header=T); head(f5p)
# f5p<-arrange(f5p,CID)%>%
#   dplyr::select(RskCstDev:RskWtrShdPl)

f6p<-read.csv(file="pts_distBgyTownRiver.csv", header=T);head(f6p)
f6p<-arrange(f6p,CID)%>%
  dplyr::select(distBgy.km:distRiver.km)

# f7p<- read.csv(file="pts_FishingYrs_Norm.csv", header=T)
# head(f7p)

# currently using cumulative version insead (see below)

f8p<- read.csv(file="pts_FishingYrsCumulative.csv",header=T); head(f8p)
f8p<-arrange(f8p,CID)%>%
  dplyr::select(fYr00A:fYrLag50A) 
# select for values standardized against max for all years
# qplot(f8p$fYr00A)

f9p<- read.csv(file="pts_FishingYrs_Dest_Cumulative.csv",header=T); head(f9p)
f9p<-arrange(f9p,CID)%>%
  dplyr::select(dfYr00A:dfYrLag50A) 
# select for values standardized against max for all years
# qplot(f9p$dfYr00A)

f10p<- read.csv(file="pts_PopRsk_Norm.csv",header=T); head(f10p)
f10p<-arrange(f10p,CID)%>%
  dplyr::select(PopRskDecay,PopRsk.Nrm) 

f11p<- read.csv(file="pts_ThermStress.csv",header=T); head(f11p)
f11p<-arrange(f11p,CID)%>%
	dplyr::select(therm_98_07) 
head(f11p)

f12p<- read.csv(file="pts_FishingYrs_Dif.csv",header=T); head(f12p)
f12p<-arrange(f12p,CID)%>%
	dplyr::select(allDif_00_90:allDif_90_80) 
head(f12p)

f13p<- read.csv(file="pts_FishingYrsDest_Dif.csv",header=T); head(f13p)
f13p<-arrange(f13p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f13p)

# g1n measures
# cumulative
f14p<- read.csv(file="pts_cumFishing_g1n_blast.csv",header=T); head(f14p)
f14p<-arrange(f14p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f14p)

f15p<- read.csv(file="pts_cumFishing_g1n_kaykay.csv",header=T); head(f15p)
f15p<-arrange(f15p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f15p)

f16p<- read.csv(file="pts_cumFishing_g1n_poison.csv",header=T); head(f16p)
f16p<-arrange(f16p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f16p)

f16p2<- read.csv(file="pts_cumFishing_g1n_g5poison.csv",header=T); head(f16p2)
f16p2<-arrange(f16p2,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f16p2)

# difference
f17p<- read.csv(file="pts_difFishing_g1n_blast.csv",header=T); head(f17p)
f17p<-arrange(f17p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f17p)

f18p<- read.csv(file="pts_difFishing_g1n_kaykay.csv",header=T); head(f18p)
f18p<-arrange(f18p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f18p)

f19p<- read.csv(file="pts_difFishing_g1n_poison.csv",header=T); head(f19p)
f19p<-arrange(f19p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f19p)

# lag
f20p<- read.csv(file="pts_lagFishing_g1n_blast.csv",header=T); head(f20p)
f20p<-arrange(f20p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f20p)

f21p<- read.csv(file="pts_lagFishing_g1n_kaykay.csv",header=T); head(f21p)
f21p<-arrange(f21p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f21p)

f22p<- read.csv(file="pts_lagFishing_g1n_poison.csv",header=T); head(f22p)
f22p<-arrange(f22p,CID)%>%
	dplyr::select(-x,-y,-CID) 
head(f22p)

####################################
# join new tables to original pt table
####################################
# head(pt@data)
pt@data=cbind(pt@data,f1p,f2p,f3p,f6p,f8p,f9p,f10p,f11p, f12p,f13p,f14p,f15p,f16p,f16p2,f17p,f18p,f19p,f20p,f21p,f22p) #f7p, f4p,f5p,
head(pt@data)

############### 
# join CID and x y data to data.frame
# pt@data$CID
coord<-data.frame(coordinates(pt))#"CID"
names(coord)<-c("x","y") 

pt2<-pt@data
ptall<-data.frame(cbind(coord,pt2)) #confirmed same CID
head(ptall)

###################
# Remove NAs for fishing and risk data
pt3<-dplyr::filter(ptall,allEffort2010>=0)
pt4<-dplyr::filter(pt3,destEffort2010>=0)
pt5<-dplyr::filter(pt4,SIGen2010>=0)
# pt5<-dplyr::filter(pt5,RskCstDev>=0) 

head(pt5)
# not sure how this skews where the points are located, prob better to fill in with closest value

# remove outlier - tiny coral takot
pt5<-filter(pt5,PtID!=4215)
pt5[pt5$PtID==4215] # gone anyways...

###############
# remove points that are within 100m of MPAs
loc2=("C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/data/MPAs")
setwd(loc2)

# load shapefile of those
pt_MPA<-readOGR(".", "PointsIn100mofMPA")
head(pt_MPA@data)
ptMPA2<-data.frame(pt_MPA@data$PtID)
names(ptMPA2)<-"PtID"; head(ptMPA2)

# remove points near MPAs
pt6<-pt5
for (i in 1:length(ptMPA2)){
	pt6<-filter(pt6,PtID!=ptMPA2[i,])
}

# confirm the only levels are 0 & 1
levels(as.factor(pt5$Id_resil))

####################
# Save files
####################
loc1=("C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/results/RS_only")
setwd(loc1)

# write output as csv
# all data
write.table(pt6,file="IndpVar_Pts_RS.csv",sep=",",col.names=T,row.names=F)


############
# # Make SpatialPointsDataFrame
#all data
pt5c<-pt6
coordinates(pt5c)<-c("x","y")
#all data
proj4string(pt5c) <- "+proj=utm +zone=51 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0"

# write out a new shapefile (including .prj component) 
writeOGR(pt5c, ".", "IndpVar_Pts_RS", overwrite_layer=T,driver="ESRI Shapefile")

# To satisfy reviewers complaint that there were too many points, I exported this file to GIS and then I subsampled the point data using create random points and restricting the points to the IndpVar shapefile. Two versions: (1) 1000 points and (2) 500 points 250 m apart (this might build spatial structure into data so I think is less ideal, but this is what the reviewers wanted so I am creating the sample anyways...)

# setwd to bin
setwd("C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/bin/")

