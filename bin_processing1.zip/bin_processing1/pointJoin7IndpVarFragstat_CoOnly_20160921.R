# Jennifer Selgrath
# Project Seahorse, UBC
# Sept 21, 2016 #Autumn!!

###########################################
# GOAL: Join random points to fragstat data from Coral only - for correct distance to coral (indp var)
###########################################

#########################################################################
# OBJECTIVE 1: Load and organize files 
############################################################################################
remove(list=ls())

############################
# TASK 1.1 Load point files

# version 1 - from ESRI shapefile # could also use .csv file
loc=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/results/RS_only")
setwd(loc)

# ogrInfo(".", "hab_Resil_Pts_RS")
pts<-readOGR(".", "hab_Resil_Pts_RS")
head(pts@data)
# str(pts)


############################
# Task 1.2 load shapefile with indp data from fragstats
loc1=("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/data/prox") #these are for Coral Area

# this is for Coral only

setwd(loc1)

##################################
# Task 1.3 load shapefile with landscape variables for coral areas
frag<-readOGR(".", "RS_CoFrag")
head(frag@data)
plot(frag)
frag


###########################################
# Extract  Variables to Point Data
# intersect points in polygon
pts2 <- point.in.poly(pts, frag)
pts2@data

# convert to data frame, keeping your data
pts3<- as.data.frame(pts2)
head(pts3)
names(pts3)

pts4<-dplyr::select(pts3,CID,GRIDCODE,AREA:ENN); head(pts4)

########################333
#export table
setwd(loc) #results folder
write.table(pts4,file="pts_Co_Frag_RS.csv", sep=",", col.names=T, row.names=F)

# set wd to bin
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch4/Resilience/bin/")
