# Jennifer Selgrath
# Project Seahorse, UBC

# ------------------------------------------------------------------
# driver
remove(list=ls())
setwd("C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/bin/")
loc<-"C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/bin/"

# SET FOLDER TO TRAIN OR TEST DATA BASED ON WHAT WANT TO SOURCE

# libraries
source("loadlibrariesatstart.R")

###########
# see folder: FishingMeasures for code to extract various measures of fishing effort
###########

###########
# Before run this code, First set random points in ArcGIS and save in ".../Ch5/Resilience/data/randompoints/")
##########

# join points to coral/rubble data
source("pointJoin1Resilience_RS_20160627.R")
# output: 

#########################
# FOR Independent Data - SAVES TO SAME FILE AS REGULAR SO SAVE ORIG FOLDER WITH NEW NAME
#######################

# join points with fishing effort data from 2010, gear diversity. 
# FYI - not using in analysis because better measures below.
source("pointJoin2IndpVarFishingNorm_RS_20160627.R")
# output: pts_FishingImpactNorm.csv

##################
# join points with fishing effort data (all fishing) from decades
##################
# create normalized impact values for each year '.Nrm' and for all years '.NrmA'
source("pointJoin3FishingAllYrs_1Norm_20160630.R")
# output: pts_FishingYrs_Norm.csv

# cumulative fishing ?and lag? (additative) - ALL gears
source("pointJoin3FishingAllYrs_2Cumulative_20160803.R")
# output: pts_FishingYrsCumulative.csv

# difference in fishing among years
source("pointJoin3FishingAllYrs_4Dif_20160916.R")
# output: pts_FishingYrs_Dif.csv

##################
# join points with fishing effort data (g1n and some g5n and categories from Ch3) from decades
##################
# create normalized impact values for each year '.Nrm' and for all years '.NrmA'
source("pointJoin4Fishing_g1n_1Cum_20161108.R")
# output: pts_cumFishing_g1n_GEAR.csv

source("pointJoin4Fishing_g1n_2Lag_20161108.R")
# output: pts_lagFishing_g1n_g5poison.csv

source("pointJoin4Fishing_g1n_3Dif_20161108.R")
#output: pts_difFishing_g1n_GEAR.csv

##################
# join points with fishing effort data (destructive) from decades
##################
# join points with dest fishing data from decades
source('pointJoin5FishingDestYrsNorm_20160803.R')
# output: pts_FishingYrsDest_Norm.csv

# join points with changes in dest fishing
source("pointJoin5FishingDestYrsDif_20160916.R")
#output: pts_FishingYrsDest_Dif.csv

# cumulative fishing (additative) - DESTRUCTIVE GEARS
source("pointJoin6FishingYrsDest_NormCumulative_20160803.R")
# output: pts_FishingYrs_Dest_Cumulative.csv

# join points with fragstats output 
source("pointJoin7IndpVarFragstat_20160627_RS.R")

# join to other indp var
source("pointJoin8IndpVarOther_RS_20160627.R")

# join pointsto risk data from Reefs at Risk Revisited 
#NOTE: Stopped using because did not make sense locally
source("pointJoin9Risks_RS_20160808.R")
# output: Risks_Pts_RS

# Distance Rasters (Town, Bgy, River)
source("pointJoin10IndpVarDist_RS_20160731.R")

# source Population Density Decay based risk map. This is better that reefs at risk.
# PopRsk2: based on buffers. 
# PopRskDecay: based on 1/sqrt(distance)*population density rank
# 20180621 - changed pop risk to entire study area (no longer clipped)
source("pointJoin11_PopRsk_RS_20160811.R")
#output: pts_PopRsk_Norm.csv

# # calculate prox of SG. RS data only.
# # input .csv from GenerateNearTable Tool in ArcGIS.
# source("pointJoin12habitatSGall_data_prox_u_20160628.R")
# source("pointJoin13habitatSGall_data_prox_spatial_20160621.R") 
# 
# #and for MG
# source("pointJoin14habitatMGall_data_prox_u_20160627.R")
# source("pointJoin15habitatMG_data_prox_spatial_20160627.R") 

# This is just from EcuDist in GIS. Simpler than above. 
# With LEK sg in inner channel and updated mg on olango
source("pointJoin12habitatDist_SgMgCo_20160916.R")

#update dist to coral for coral locations with data from Fragstats
source("pointJoin12habitatDist_updateCoWithENN_20160921.R")
source("pointJoin12habitatDist_updateCoWithENN_GT.R") #For Testing data
#output: pts_Co_Mg_Sg_minDist2.csv

source("pointJoin16_thermalStress98_07_20160907.R")
# output: pts_ThermStress.csv

# merge all points together
source("point_MergeAll_RS_20180618.R") #20160930.R") 
#Jul31 is version with Prox data - now no points in 100m of MPAs and g1n
#output:  IndpVar_Pts_RS.shp/csv     IndpVar_Pts3000_RS.shp/csv


############
# analyses setup
############
remove(list=ls())
setwd("C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/bin/")

# reduce # of variables to reign things in a bit
source("Q_All_dataSetup1_ReduceVariables_20160831.R") 
#output: IndpVar_Ptsa_RS.csv

# log transform variables
source("Q_All_dataSetup2_LogTransformations_20161028.R")
#output: IndpVar_Ptsb_RS.csv

# center and standardize using z-scale transformation 
source("Q_All_dataSetup3_20161028.R")
#output: IndpVar_Ptsc_RS.csv # exporting z-transformed and orig log data only
#output: IndpVar_Ptsc_MeanSD.csv  # mean and SD of log tranformed data for back transforming later

# remove olango, combine coastal and terr islands
# remove outlier
# run all data setup
source("Q_All_dataSetup4_20161028.R") #was analysis setup
# output: IndpVar_Ptsd_RS.csv = Data without any points on Olango
# output: IndpVar_Ptsd_NoCoastalTerr_RS.csv = Data without Olango, Coastal, or Terr. Islands

# ##bring this output into ArcGIS to sub sample using create random points, and spatial join back to data
# toolbox: Ch5_resilience>subsetPoints_20180619


# create a .csv file from smaller sample size of data
# this added June 2018 in response to reviewer comments
source("point_dataSubset_20180619.R")
# input:  points_1000_data.csv            points_500_250m_data.shp      
# output: IndpVar_Pts_RS_1000.csv     IndpVar_Pts_RS_500_250m.csv

# make formal names for final models.
# this code has a selection between full dataset, 1000 pts, and 500 pts 250 m apart
# input = IndpVar_Ptsd_RS.csv
source("Q_All_dataSetup5_20161028_LongNames.R") # Was Q_LongNames_20160930.R 
# output: IndpVar_Ptse_RS.csv = Data with long names
# output: IndpVar_Ptsf_RS.csv = Long names only
### NOTE: Output DOES NOT(!!!!) specify if data is all points, 1000 points, or 500 points

# look at variables
# source("Q_All_correlationsViz.R") # no output saved # this is pretty old



####################
# Analyses
####################
setwd("C:/Users/jselg/Dropbox/1PhD/R.projects/Ch5/Resilience/bin/")

# model with 1 random effect
source("Q41_analysis_20180623_mixedEf1.R")

# graph models
source("Q41_ModelVizGraph_miEffects2.R")

# graph models for paper
source("Q41_Fig4.R")
# input: ./results/RS_only/Q41_model_20161109_mixedEf1_52.R
# output: Fig4

# model residuals
source("Q41_Residuals_ExportingMixedEf.R")
# source("Q41_Residuals_Graphing.R")
source("Q41_FigS2.R")

#########
# re-run models with testing data
# First, create data by subbing testing points in for real points by renaming folders
# Note: Easier to do manually by changing folder names so code stays updated.
source("Q_All_dataSetup1_ReduceVariables_20160831.R") 
#output: IndpVar_Ptsa_RS.csv

# log transform variables
source("Q_All_dataSetup2_LogTransformations_20161028.R")
source("Q_All_dataSetup3_20161028.R")
source("Q_All_dataSetup4_20161028.R") #was analysis setup
source("Q_All_dataSetup5_20161028_LongNames.R")


################
# Analysis
source("Q51_analysis_m_me_testingData_20161028.R")
#output: Q51_data_test.csv

source("Q51_Fig6_ ModelVizGraph_TestingData.R")









##################################################
#############
# Below are old models
##########
# model with all variables
source("Q11_analysis_20160819.R")
# output: Q11_model_20160816.R = final model (m8)

# examine residuals
source("Q11_residuals_20160826.R")

#setup data for graphing final model
source("Q11_ModelVizDataSetup_20160826.R")

#graphing final model
source("Q11_ModelVizGraph_20160826.R")

#Exporting Residuals to map in ArcGIS
source("Q11_ExportingResiduals_20160816.R")


##############
# Redoing analysis with mixed effects & with no dest fishing
##############
source("Q11_analysis_20160831_MixedEf2a.R")
# output: Q11_model_20160831_mixedEf2a.R

source("Q11_ModelVizDataSetup_MiEffects2_20160830.R") #not needed if use sjp.glmer

source("Q11_ModelVizGraph_MiEffects2a.R") #with sjp.glmer
source("Q11_analysis_20160831_MixedEf2b.R")
#Q11_model_20160831_mixedEf2b.R
source("Q11_ModelVizGraph_MiEffects2b.R")
# several




################################
# Run model with independent data
# This code needs updating for fishing
##########################
# reset data setup to be for Ground TRuthing points
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch5/Resilience/bin/")

source("pointJoin21Resilience_GT.R")
source("pointJoin22IndpVarFishingNorm_GT.R")
source("pointJoin23FishingAllYrsNorm_GT.R")
source("pointJoin24FishingYrs_NormCumulative_GT.R")
source('pointJoin25FishingDestYrsNorm_GT.R')
source("pointJoin26FishingYrsDest_NormCumulative_GT.R")
source("pointJoin27IndpVarFragstat_GT.R")
source("pointJoin28IndpVarOther_GT.R")
# source("pointJoin29Risks_GT.R")
source("pointJoin30IndpVarDist_GT.R")
source("pointJoin31_PopRsk_GT.R")

# source("pointJoin32habitatSGall_data_prox_u_20160628.R")
# source("pointJoin33habitatSGall_data_prox_spatial_20160621.R") 
# source("pointJoin34habitatMGall_data_prox_u_20160627.R")
# source("pointJoin35habitatMG_data_prox_spatial_20160627.R") 

# This is just from EcuDist in GIS. Simpler than above. 
# With LEK sg in inner channel and updated mg on olango
source("pointJoin32habitatDist_SgMg_20160831.R")

source("pointJoin36_thermalStress98_07_20160907.R") # output: pts_ThermStress.csv

source("point_MergeAll_GT.R") #output:  IndpVar_Pts_GT.shp/csv  

############
# analyses
############
setwd("C:/Users/Jenny/Dropbox/1PhD/R.projects/Ch5/Resilience/bin/")

# reduce # of variables to reign thigns in a bit
source("Q31_All_dataSetup_ReduceVariables_GT.R") #updated aug 1 2016
#output: IndpVar_Pts1000b_GT.csv

# remove Olango
source("Q31_analysisSetup_GT.R")

# model with all variables
source("Q31_analysis_m_me2b_GT.R")
# source("Q31_analysis_All.R") #probabilities for non-heirarchical models that fit well. Here with simplified output

#orig
source("Q31_ModelVizGraph_MiEffects2b_GT.R")
source("Q11_ModelVizGraph_MiEffects2b_simple11.R") #or simple12
source("Q11_Residuals_ExportingMixedEf_simple11.R")

# updated with interactions
source("Q31_analysis_20160923_MixedEf1b_simple2b.R")
source("Q31_Residuals_ExportingMixedEf_simple18b2.R")
source("Q31_ModelVizGraph_MiEffects1b_simple18b.R")

# graph predicted values
# source("Q31_ModelVizGraph_GT.R")
# output (in doc): PredictedProb_box.png
